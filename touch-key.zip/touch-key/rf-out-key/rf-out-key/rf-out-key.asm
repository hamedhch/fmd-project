//Deviec:FT60F01X
//-----------------------Variable---------------------------------
		_PA0		EQU		05H
		_PA1		EQU		05H
		_PA2		EQU		05H
		_PA3		EQU		05H
		_PA4		EQU		05H
		_PA5		EQU		05H
		_T0IF		EQU		0BH
		_T0IE		EQU		0BH
		_PEIE		EQU		0BH
		_GIE		EQU		0BH
		_TMR2IF		EQU		0CH
		_EEIF		EQU		0CH
		_TMR2ON		EQU		12H
		_TMR2IE		EQU		8CH
		_RD		EQU		9CH
		_WR		EQU		9DH
		_Timer		EQU		5BH
		_conternotRF		EQU		59H
		_conterout		EQU		57H
		_conteroutnot		EQU		55H
		_Data		EQU		52H
		_Time		EQU		79H
		_DataM		EQU		4FH
		_DataS		EQU		40H
		_RFData		EQU		4CH
		_eerom		EQU		60H
		_lastKey		EQU		5FH
		_Count		EQU		78H
		_Buffer		EQU		5EH
		_Bit		EQU		5DH
		_O1		EQU		71H
		_O2		EQU		71H
		_O3		EQU		70H
		_O4		EQU		70H
		_Start		EQU		70H
		_state1		EQU		77H
		_state2		EQU		77H
		_state3		EQU		77H
		_state4		EQU		77H
		_LernRFblink		EQU		70H
		_LernRF		EQU		70H
		_Frist		EQU		70H
		_Finish		EQU		70H
		_Lock		EQU		70H
//		main@i_656		EQU		6BH
//		main@i		EQU		6AH
//		EEPROMwrite@EEAddr		EQU		76H
//		EEPROMwrite@EEAddr		EQU		76H
//		EEPROMwrite@Data		EQU		61H
//		EEPROMwrite@EEAddr		EQU		76H
//		EEPROMread@EEAddr		EQU		61H
//		EEPROMread@ReEEPROMread		EQU		62H
//		EEPROMread@EEAddr		EQU		61H
//		EEPROMread@EEAddr		EQU		61H
//		DelayMs@b		EQU		67H
//		DelayMs@a		EQU		65H
//		DelayMs@Time		EQU		63H
//		DelayUs@Time		EQU		61H
//		DelayUs@a		EQU		62H
//		DelayUs@Time		EQU		61H
//		DelayUs@Time		EQU		61H
//-----------------------Variable END---------------------------------

		LJUMP 	0CH 			//0000 	380C
		ORG		0004H
		STR 	7EH 			//0004 	01FE
		SWAPR 	STATUS,0 		//0005 	0703
		STR 	73H 			//0006 	01F3
		LDR 	FSR,0 			//0007 	0804
		STR 	74H 			//0008 	01F4
		LDR 	PCLATH,0 		//0009 	080A
		STR 	75H 			//000A 	01F5
		LJUMP 	196H 			//000B 	3996
		LJUMP 	0DH 			//000C 	380D
		LDWI 	40H 			//000D 	2A40
		CLRR 	70H 			//000E 	0170
		CLRR 	71H 			//000F 	0171
		CLRR 	78H 			//0010 	0178
		CLRR 	79H 			//0011 	0179
		BCR 	STATUS,7 		//0012 	1383
		STR 	FSR 			//0013 	0184
		LDWI 	61H 			//0014 	2A61
		LCALL 	37CH 			//0015 	337C
		CLRR 	STATUS 			//0016 	0103
		LJUMP 	18H 			//0017 	3818

		//;rf-out-key.C: 276: POWER_INITIAL();
		LCALL 	343H 			//0018 	3343

		//;rf-out-key.C: 277: TIMER2_INITIAL();
		LCALL 	353H 			//0019 	3353

		//;rf-out-key.C: 278: TIMER0_INITIAL();
		LCALL 	36AH 			//001A 	336A

		//;rf-out-key.C: 280: TMR2IE = 1;
		BSR 	STATUS,5 		//001B 	1A83
		BSR 	CH,1 			//001C 	188C

		//;rf-out-key.C: 283: state1=EEPROMread(31);
		LDWI 	1FH 			//001D 	2A1F
		LCALL 	373H 			//001E 	3373
		STR 	69H 			//001F 	01E9
		RRR	69H,0 			//0020 	0669
		BTSS 	STATUS,0 		//0021 	1C03
		LJUMP 	25H 			//0022 	3825
		BSR 	77H,3 			//0023 	19F7
		LJUMP 	26H 			//0024 	3826
		BCR 	77H,3 			//0025 	11F7

		//;rf-out-key.C: 284: state2=EEPROMread(32);
		LDWI 	20H 			//0026 	2A20
		LCALL 	373H 			//0027 	3373
		STR 	69H 			//0028 	01E9
		RRR	69H,0 			//0029 	0669
		BTSS 	STATUS,0 		//002A 	1C03
		LJUMP 	2EH 			//002B 	382E
		BSR 	77H,2 			//002C 	1977
		LJUMP 	2FH 			//002D 	382F
		BCR 	77H,2 			//002E 	1177

		//;rf-out-key.C: 285: state3=EEPROMread(33);
		LDWI 	21H 			//002F 	2A21
		LCALL 	373H 			//0030 	3373
		STR 	69H 			//0031 	01E9
		RRR	69H,0 			//0032 	0669
		BTSS 	STATUS,0 		//0033 	1C03
		LJUMP 	37H 			//0034 	3837
		BSR 	77H,1 			//0035 	18F7
		LJUMP 	38H 			//0036 	3838
		BCR 	77H,1 			//0037 	10F7

		//;rf-out-key.C: 286: state4=EEPROMread(34);
		LDWI 	22H 			//0038 	2A22
		LCALL 	373H 			//0039 	3373
		STR 	69H 			//003A 	01E9
		RRR	69H,0 			//003B 	0669
		BTSS 	STATUS,0 		//003C 	1C03
		LJUMP 	40H 			//003D 	3840
		BSR 	77H,0 			//003E 	1877
		LJUMP 	41H 			//003F 	3841
		BCR 	77H,0 			//0040 	1077

		//;rf-out-key.C: 289: PA4=state1;
		BTSS 	77H,3 			//0041 	1DF7
		LJUMP 	46H 			//0042 	3846
		BCR 	STATUS,5 		//0043 	1283
		BSR 	5H,4 			//0044 	1A05
		LJUMP 	48H 			//0045 	3848
		BCR 	STATUS,5 		//0046 	1283
		BCR 	5H,4 			//0047 	1205

		//;rf-out-key.C: 290: PA0=state2;
		BTSS 	77H,2 			//0048 	1D77
		LJUMP 	4DH 			//0049 	384D
		BCR 	STATUS,5 		//004A 	1283
		BSR 	5H,0 			//004B 	1805
		LJUMP 	4FH 			//004C 	384F
		BCR 	STATUS,5 		//004D 	1283
		BCR 	5H,0 			//004E 	1005

		//;rf-out-key.C: 291: PA1=state3;
		BTSS 	77H,1 			//004F 	1CF7
		LJUMP 	54H 			//0050 	3854
		BCR 	STATUS,5 		//0051 	1283
		BSR 	5H,1 			//0052 	1885
		LJUMP 	56H 			//0053 	3856
		BCR 	STATUS,5 		//0054 	1283
		BCR 	5H,1 			//0055 	1085

		//;rf-out-key.C: 292: PA5=state4;
		BTSS 	77H,0 			//0056 	1C77
		LJUMP 	5BH 			//0057 	385B
		BCR 	STATUS,5 		//0058 	1283
		BSR 	5H,5 			//0059 	1A85
		LJUMP 	5DH 			//005A 	385D
		BCR 	STATUS,5 		//005B 	1283
		BCR 	5H,5 			//005C 	1285

		//;rf-out-key.C: 294: char i;
		//;rf-out-key.C: 295: for(i=0;i<4;i++)
		CLRR 	6AH 			//005D 	016A
		CLRWDT	 			//005E 	0001

		//;rf-out-key.C: 298: DataS[i][0]=EEPROMread(i*3);
		BCR 	STATUS,5 		//005F 	1283
		LDR 	6AH,0 			//0060 	086A
		ADDWR 	6AH,0 			//0061 	0B6A
		ADDWR 	6AH,0 			//0062 	0B6A
		ADDWI 	40H 			//0063 	2740
		STR 	FSR 			//0064 	0184
		LDR 	6AH,0 			//0065 	086A
		ADDWR 	6AH,0 			//0066 	0B6A
		ADDWR 	6AH,0 			//0067 	0B6A
		LCALL 	373H 			//0068 	3373

		//;rf-out-key.C: 299: DataS[i][1]=EEPROMread((i*3)+1);
		LCALL 	180H 			//0069 	3180
		ADDWI 	41H 			//006A 	2741
		STR 	FSR 			//006B 	0184
		LDR 	6AH,0 			//006C 	086A
		ADDWR 	6AH,0 			//006D 	0B6A
		ADDWR 	6AH,0 			//006E 	0B6A
		ADDWI 	1H 			//006F 	2701
		LCALL 	373H 			//0070 	3373

		//;rf-out-key.C: 300: DataS[i][2]=EEPROMread((i*3)+2);
		LCALL 	180H 			//0071 	3180
		ADDWI 	42H 			//0072 	2742
		STR 	FSR 			//0073 	0184
		LDR 	6AH,0 			//0074 	086A
		ADDWR 	6AH,0 			//0075 	0B6A
		ADDWR 	6AH,0 			//0076 	0B6A
		ADDWI 	2H 			//0077 	2702
		LCALL 	373H 			//0078 	3373
		BCR 	STATUS,7 		//0079 	1383
		STR 	INDF 			//007A 	0180
		LDWI 	4H 			//007B 	2A04
		INCR	6AH,1 			//007C 	09EA
		SUBWR 	6AH,0 			//007D 	0C6A
		BTSS 	STATUS,0 		//007E 	1C03
		LJUMP 	5EH 			//007F 	385E

		//;rf-out-key.C: 301: }
		//;rf-out-key.C: 304: Start=0;
		BCR 	70H,5 			//0080 	12F0

		//;rf-out-key.C: 306: while(1)
		CLRWDT	 			//0081 	0001

		//;rf-out-key.C: 310: if(eerom!=0){
		BCR 	STATUS,5 		//0082 	1283
		LDR 	60H,0 			//0083 	0860
		BTSC 	STATUS,2 		//0084 	1503
		LJUMP 	C1H 			//0085 	38C1

		//;rf-out-key.C: 311: if(eerom==1)EEPROMwrite(31,state1);
		DECRSZ 	60H,0 		//0086 	0E60
		LJUMP 	92H 			//0087 	3892
		BCR 	STATUS,0 		//0088 	1003
		BTSC 	77H,3 			//0089 	15F7
		BSR 	STATUS,0 		//008A 	1803
		LDWI 	0H 			//008B 	2A00
		BTSC 	STATUS,0 		//008C 	1403
		LDWI 	1H 			//008D 	2A01
		STR 	61H 			//008E 	01E1
		LDWI 	1FH 			//008F 	2A1F
		CLRR 	62H 			//0090 	0162
		LCALL 	32EH 			//0091 	332E

		//;rf-out-key.C: 312: if(eerom==2)EEPROMwrite(32,state2);
		LDWI 	2H 			//0092 	2A02
		BCR 	STATUS,5 		//0093 	1283
		XORWR 	60H,0 			//0094 	0460
		BTSS 	STATUS,2 		//0095 	1D03
		LJUMP 	A1H 			//0096 	38A1
		BCR 	STATUS,0 		//0097 	1003
		BTSC 	77H,2 			//0098 	1577
		BSR 	STATUS,0 		//0099 	1803
		LDWI 	0H 			//009A 	2A00
		BTSC 	STATUS,0 		//009B 	1403
		LDWI 	1H 			//009C 	2A01
		STR 	61H 			//009D 	01E1
		LDWI 	20H 			//009E 	2A20
		CLRR 	62H 			//009F 	0162
		LCALL 	32EH 			//00A0 	332E

		//;rf-out-key.C: 313: if(eerom==3)EEPROMwrite(33,state3);
		LDWI 	3H 			//00A1 	2A03
		BCR 	STATUS,5 		//00A2 	1283
		XORWR 	60H,0 			//00A3 	0460
		BTSS 	STATUS,2 		//00A4 	1D03
		LJUMP 	B0H 			//00A5 	38B0
		BCR 	STATUS,0 		//00A6 	1003
		BTSC 	77H,1 			//00A7 	14F7
		BSR 	STATUS,0 		//00A8 	1803
		LDWI 	0H 			//00A9 	2A00
		BTSC 	STATUS,0 		//00AA 	1403
		LDWI 	1H 			//00AB 	2A01
		STR 	61H 			//00AC 	01E1
		LDWI 	21H 			//00AD 	2A21
		CLRR 	62H 			//00AE 	0162
		LCALL 	32EH 			//00AF 	332E

		//;rf-out-key.C: 314: if(eerom==4)EEPROMwrite(34,state4);
		LDWI 	4H 			//00B0 	2A04
		BCR 	STATUS,5 		//00B1 	1283
		XORWR 	60H,0 			//00B2 	0460
		BTSS 	STATUS,2 		//00B3 	1D03
		LJUMP 	BFH 			//00B4 	38BF
		BCR 	STATUS,0 		//00B5 	1003
		BTSC 	77H,0 			//00B6 	1477
		BSR 	STATUS,0 		//00B7 	1803
		LDWI 	0H 			//00B8 	2A00
		BTSC 	STATUS,0 		//00B9 	1403
		LDWI 	1H 			//00BA 	2A01
		STR 	61H 			//00BB 	01E1
		LDWI 	22H 			//00BC 	2A22
		CLRR 	62H 			//00BD 	0162
		LCALL 	32EH 			//00BE 	332E

		//;rf-out-key.C: 315: eerom=0;
		BCR 	STATUS,5 		//00BF 	1283
		CLRR 	60H 			//00C0 	0160

		//;rf-out-key.C: 316: }
		//;rf-out-key.C: 319: if(LernRFblink==1){
		BTSS 	70H,4 			//00C1 	1E70
		LJUMP 	FBH 			//00C2 	38FB

		//;rf-out-key.C: 321: if(lastKey==1) DelayMs(200) ,PA4=!PA4 , DelayMs(200) , PA4=!PA4 ;
		DECRSZ 	5FH,0 		//00C3 	0E5F
		LJUMP 	CEH 			//00C4 	38CE
		LDWI 	C8H 			//00C5 	2AC8
		STR 	63H 			//00C6 	01E3
		CLRR 	64H 			//00C7 	0164
		LCALL 	312H 			//00C8 	3312
		LDWI 	10H 			//00C9 	2A10
		LCALL 	18CH 			//00CA 	318C
		LCALL 	312H 			//00CB 	3312
		LDWI 	10H 			//00CC 	2A10
		XORWR 	5H,1 			//00CD 	0485

		//;rf-out-key.C: 322: if(lastKey==2) DelayMs(200) ,PA0=!PA0 , DelayMs(200) , PA0=!PA0 ;
		LDWI 	2H 			//00CE 	2A02
		XORWR 	5FH,0 			//00CF 	045F
		BTSS 	STATUS,2 		//00D0 	1D03
		LJUMP 	DBH 			//00D1 	38DB
		LDWI 	C8H 			//00D2 	2AC8
		STR 	63H 			//00D3 	01E3
		CLRR 	64H 			//00D4 	0164
		LCALL 	312H 			//00D5 	3312
		LDWI 	1H 			//00D6 	2A01
		LCALL 	18CH 			//00D7 	318C
		LCALL 	312H 			//00D8 	3312
		LDWI 	1H 			//00D9 	2A01
		XORWR 	5H,1 			//00DA 	0485

		//;rf-out-key.C: 323: if(lastKey==3) DelayMs(200) ,PA1=!PA1 , DelayMs(200) , PA1=!PA1 ;
		LDWI 	3H 			//00DB 	2A03
		XORWR 	5FH,0 			//00DC 	045F
		BTSS 	STATUS,2 		//00DD 	1D03
		LJUMP 	E8H 			//00DE 	38E8
		LDWI 	C8H 			//00DF 	2AC8
		STR 	63H 			//00E0 	01E3
		CLRR 	64H 			//00E1 	0164
		LCALL 	312H 			//00E2 	3312
		LDWI 	2H 			//00E3 	2A02
		LCALL 	18CH 			//00E4 	318C
		LCALL 	312H 			//00E5 	3312
		LDWI 	2H 			//00E6 	2A02
		XORWR 	5H,1 			//00E7 	0485

		//;rf-out-key.C: 324: if(lastKey==4) DelayMs(200) ,PA5=!PA5 , DelayMs(200) , PA5=!PA5 ;
		LDWI 	4H 			//00E8 	2A04
		XORWR 	5FH,0 			//00E9 	045F
		BTSS 	STATUS,2 		//00EA 	1D03
		LJUMP 	F5H 			//00EB 	38F5
		LDWI 	C8H 			//00EC 	2AC8
		STR 	63H 			//00ED 	01E3
		CLRR 	64H 			//00EE 	0164
		LCALL 	312H 			//00EF 	3312
		LDWI 	20H 			//00F0 	2A20
		LCALL 	18CH 			//00F1 	318C
		LCALL 	312H 			//00F2 	3312
		LDWI 	20H 			//00F3 	2A20
		XORWR 	5H,1 			//00F4 	0485

		//;rf-out-key.C: 326: LernRFblink=0;
		BCR 	70H,4 			//00F5 	1270

		//;rf-out-key.C: 327: conternotRF=0;
		CLRR 	59H 			//00F6 	0159
		CLRR 	5AH 			//00F7 	015A

		//;rf-out-key.C: 328: LernRF=1;
		BSR 	70H,3 			//00F8 	19F0

		//;rf-out-key.C: 329: TMR2IE = 1;
		BSR 	STATUS,5 		//00F9 	1A83
		BSR 	CH,1 			//00FA 	188C

		//;rf-out-key.C: 330: }
		//;rf-out-key.C: 332: if(Lock==1 & LernRF==0)
		BTSS 	70H,3 			//00FB 	1DF0
		BTSS 	70H,0 			//00FC 	1C70
		LJUMP 	131H 			//00FD 	3931

		//;rf-out-key.C: 333: {
		//;rf-out-key.C: 334: Lock=0;
		BCR 	70H,0 			//00FE 	1070

		//;rf-out-key.C: 335: char i;
		//;rf-out-key.C: 336: for(i=0;i<4;i++)
		BCR 	STATUS,5 		//00FF 	1283
		CLRR 	6BH 			//0100 	016B

		//;rf-out-key.C: 337: {
		//;rf-out-key.C: 338: if(DataM[0]==DataS[i][0] && DataM[1]==DataS[i][1] && DataM[2]==DataS
		//+                          [i][2])
		LDR 	6BH,0 			//0101 	086B
		ADDWR 	6BH,0 			//0102 	0B6B
		ADDWR 	6BH,0 			//0103 	0B6B
		ADDWI 	40H 			//0104 	2740
		STR 	FSR 			//0105 	0184
		BCR 	STATUS,7 		//0106 	1383
		LDR 	INDF,0 			//0107 	0800
		XORWR 	4FH,0 			//0108 	044F
		BTSS 	STATUS,2 		//0109 	1D03
		LJUMP 	12CH 			//010A 	392C
		LDR 	6BH,0 			//010B 	086B
		ADDWR 	6BH,0 			//010C 	0B6B
		ADDWR 	6BH,0 			//010D 	0B6B
		ADDWI 	41H 			//010E 	2741
		STR 	FSR 			//010F 	0184
		LDR 	50H,0 			//0110 	0850
		XORWR 	INDF,0 		//0111 	0400
		BTSS 	STATUS,2 		//0112 	1D03
		LJUMP 	12CH 			//0113 	392C
		LDR 	6BH,0 			//0114 	086B
		ADDWR 	6BH,0 			//0115 	0B6B
		ADDWR 	6BH,0 			//0116 	0B6B
		ADDWI 	42H 			//0117 	2742
		STR 	FSR 			//0118 	0184
		LDR 	51H,0 			//0119 	0851
		XORWR 	INDF,0 		//011A 	0400
		BTSS 	STATUS,2 		//011B 	1D03
		LJUMP 	12CH 			//011C 	392C

		//;rf-out-key.C: 339: {
		//;rf-out-key.C: 340: if(i==0)O1=1;
		LDR 	6BH,0 			//011D 	086B
		BTSS 	STATUS,2 		//011E 	1D03
		LJUMP 	121H 			//011F 	3921
		BSR 	71H,1 			//0120 	18F1

		//;rf-out-key.C: 341: if(i==1)O2=1;
		DECRSZ 	6BH,0 		//0121 	0E6B
		LJUMP 	124H 			//0122 	3924
		BSR 	71H,0 			//0123 	1871

		//;rf-out-key.C: 342: if(i==2)O3=1;
		LDWI 	2H 			//0124 	2A02
		XORWR 	6BH,0 			//0125 	046B
		BTSC 	STATUS,2 		//0126 	1503
		BSR 	70H,7 			//0127 	1BF0

		//;rf-out-key.C: 343: if(i==3)O4=1;
		LDWI 	3H 			//0128 	2A03
		XORWR 	6BH,0 			//0129 	046B
		BTSC 	STATUS,2 		//012A 	1503
		BSR 	70H,6 			//012B 	1B70
		LDWI 	4H 			//012C 	2A04
		INCR	6BH,1 			//012D 	09EB
		SUBWR 	6BH,0 			//012E 	0C6B
		BTSS 	STATUS,0 		//012F 	1C03
		LJUMP 	101H 			//0130 	3901

		//;rf-out-key.C: 344: }
		//;rf-out-key.C: 345: }
		//;rf-out-key.C: 347: }
		//;rf-out-key.C: 350: if(LernRF==1)
		BTSC 	70H,3 			//0131 	15F0

		//;rf-out-key.C: 351: {
		//;rf-out-key.C: 352: if(Lock==1)
		BTSS 	70H,0 			//0132 	1C70
		LJUMP 	81H 			//0133 	3881

		//;rf-out-key.C: 353: {
		//;rf-out-key.C: 356: EEPROMwrite(((lastKey-1)*3),DataM[0]);
		BCR 	STATUS,5 		//0134 	1283
		LDR 	4FH,0 			//0135 	084F
		STR 	61H 			//0136 	01E1
		LDWI 	FFH 			//0137 	2AFF
		CLRR 	62H 			//0138 	0162
		ADDWR 	5FH,0 			//0139 	0B5F
		STR 	69H 			//013A 	01E9
		ADDWR 	69H,0 			//013B 	0B69
		ADDWR 	69H,0 			//013C 	0B69
		LCALL 	32EH 			//013D 	332E

		//;rf-out-key.C: 357: DelayMs(10);
		LCALL 	191H 			//013E 	3191
		LCALL 	312H 			//013F 	3312

		//;rf-out-key.C: 358: EEPROMwrite((((lastKey-1)*3)+1),DataM[1]);
		LDR 	50H,0 			//0140 	0850
		LCALL 	186H 			//0141 	3186
		ADDWI 	FEH 			//0142 	27FE
		LCALL 	32EH 			//0143 	332E

		//;rf-out-key.C: 359: DelayMs(10);
		LCALL 	191H 			//0144 	3191
		LCALL 	312H 			//0145 	3312

		//;rf-out-key.C: 360: EEPROMwrite((((lastKey-1)*3)+2),DataM[2]);
		LDR 	51H,0 			//0146 	0851
		LCALL 	186H 			//0147 	3186
		ADDWI 	FFH 			//0148 	27FF
		LCALL 	32EH 			//0149 	332E

		//;rf-out-key.C: 361: DelayMs(10);
		LCALL 	191H 			//014A 	3191
		LCALL 	312H 			//014B 	3312

		//;rf-out-key.C: 362: DataS[lastKey-1][0]=DataM[0];
		LDR 	5FH,0 			//014C 	085F
		ADDWR 	5FH,0 			//014D 	0B5F
		ADDWR 	5FH,0 			//014E 	0B5F
		ADDWI 	3DH 			//014F 	273D
		STR 	FSR 			//0150 	0184
		LDR 	4FH,0 			//0151 	084F
		BCR 	STATUS,7 		//0152 	1383
		STR 	INDF 			//0153 	0180

		//;rf-out-key.C: 363: DataS[lastKey-1][1]=DataM[1];
		LDR 	5FH,0 			//0154 	085F
		ADDWR 	5FH,0 			//0155 	0B5F
		ADDWR 	5FH,0 			//0156 	0B5F
		ADDWI 	3EH 			//0157 	273E
		STR 	FSR 			//0158 	0184
		LDR 	50H,0 			//0159 	0850
		STR 	INDF 			//015A 	0180

		//;rf-out-key.C: 364: DataS[lastKey-1][2]=DataM[2];
		LDR 	5FH,0 			//015B 	085F
		ADDWR 	5FH,0 			//015C 	0B5F
		ADDWR 	5FH,0 			//015D 	0B5F
		ADDWI 	3FH 			//015E 	273F
		STR 	FSR 			//015F 	0184
		LDR 	51H,0 			//0160 	0851
		STR 	INDF 			//0161 	0180

		//;rf-out-key.C: 366: if(lastKey==1)conterout=20;
		DECRSZ 	5FH,0 		//0162 	0E5F
		LJUMP 	167H 			//0163 	3967
		LDWI 	14H 			//0164 	2A14
		STR 	57H 			//0165 	01D7
		CLRR 	58H 			//0166 	0158

		//;rf-out-key.C: 367: if(lastKey==2)conterout=27;
		LDWI 	2H 			//0167 	2A02
		XORWR 	5FH,0 			//0168 	045F
		BTSS 	STATUS,2 		//0169 	1D03
		LJUMP 	16EH 			//016A 	396E
		LDWI 	1BH 			//016B 	2A1B
		STR 	57H 			//016C 	01D7
		CLRR 	58H 			//016D 	0158

		//;rf-out-key.C: 368: if(lastKey==3)conterout=34;
		LDWI 	3H 			//016E 	2A03
		XORWR 	5FH,0 			//016F 	045F
		BTSS 	STATUS,2 		//0170 	1D03
		LJUMP 	175H 			//0171 	3975
		LDWI 	22H 			//0172 	2A22
		STR 	57H 			//0173 	01D7
		CLRR 	58H 			//0174 	0158

		//;rf-out-key.C: 369: if(lastKey==4)conterout=41;
		LDWI 	4H 			//0175 	2A04
		XORWR 	5FH,0 			//0176 	045F
		BTSS 	STATUS,2 		//0177 	1D03
		LJUMP 	17CH 			//0178 	397C
		LDWI 	29H 			//0179 	2A29
		STR 	57H 			//017A 	01D7
		CLRR 	58H 			//017B 	0158

		//;rf-out-key.C: 372: Lock=0;
		BCR 	70H,0 			//017C 	1070

		//;rf-out-key.C: 373: LernRF=0;
		BCR 	70H,3 			//017D 	11F0

		//;rf-out-key.C: 378: T0IE=1;
		BSR 	INTCON,5 		//017E 	1A8B
		LJUMP 	81H 			//017F 	3881
		BCR 	STATUS,7 		//0180 	1383
		STR 	INDF 			//0181 	0180
		LDR 	6AH,0 			//0182 	086A
		ADDWR 	6AH,0 			//0183 	0B6A
		ADDWR 	6AH,0 			//0184 	0B6A
		RET		 					//0185 	0004
		STR 	61H 			//0186 	01E1
		CLRR 	62H 			//0187 	0162
		LDR 	5FH,0 			//0188 	085F
		ADDWR 	5FH,0 			//0189 	0B5F
		ADDWR 	5FH,0 			//018A 	0B5F
		RET		 					//018B 	0004
		XORWR 	5H,1 			//018C 	0485
		LDWI 	C8H 			//018D 	2AC8
		STR 	63H 			//018E 	01E3
		CLRR 	64H 			//018F 	0164
		RET		 					//0190 	0004
		LDWI 	AH 			//0191 	2A0A
		BCR 	STATUS,5 		//0192 	1283
		STR 	63H 			//0193 	01E3
		CLRR 	64H 			//0194 	0164
		RET		 					//0195 	0004

		//;rf-out-key.C: 69: if(T0IE && T0IF)
		BTSC 	INTCON,5 		//0196 	168B
		BTSS 	INTCON,2 		//0197 	1D0B
		LJUMP 	28AH 			//0198 	3A8A

		//;rf-out-key.C: 70: {
		//;rf-out-key.C: 71: TMR0 = 239;
		LDWI 	EFH 			//0199 	2AEF
		BCR 	STATUS,5 		//019A 	1283
		STR 	1H 			//019B 	0181

		//;rf-out-key.C: 72: T0IF = 0;
		BCR 	INTCON,2 		//019C 	110B

		//;rf-out-key.C: 75: if(LernRF==1){
		BTSS 	70H,3 			//019D 	1DF0
		LJUMP 	1A2H 			//019E 	39A2

		//;rf-out-key.C: 76: conternotRF++;
		INCR	59H,1 			//019F 	09D9
		BTSC 	STATUS,2 		//01A0 	1503
		INCR	5AH,1 			//01A1 	09DA

		//;rf-out-key.C: 77: }
		//;rf-out-key.C: 79: if(conternotRF>=20000 ){
		LDWI 	4EH 			//01A2 	2A4E
		SUBWR 	5AH,0 			//01A3 	0C5A
		LDWI 	20H 			//01A4 	2A20
		BTSC 	STATUS,2 		//01A5 	1503
		SUBWR 	59H,0 			//01A6 	0C59
		BTSS 	STATUS,0 		//01A7 	1C03
		LJUMP 	1AFH 			//01A8 	39AF

		//;rf-out-key.C: 80: conternotRF=0;
		CLRR 	59H 			//01A9 	0159
		CLRR 	5AH 			//01AA 	015A

		//;rf-out-key.C: 82: DataM[0]=0;
		CLRR 	4FH 			//01AB 	014F

		//;rf-out-key.C: 83: DataM[1]=0;
		CLRR 	50H 			//01AC 	0150

		//;rf-out-key.C: 84: DataM[2]=0;
		CLRR 	51H 			//01AD 	0151

		//;rf-out-key.C: 86: Lock=1;
		BSR 	70H,0 			//01AE 	1870

		//;rf-out-key.C: 87: }
		//;rf-out-key.C: 90: if(PA2==0){
		BTSC 	5H,2 			//01AF 	1505
		LJUMP 	1B6H 			//01B0 	39B6

		//;rf-out-key.C: 91: conterout++;
		INCR	57H,1 			//01B1 	09D7
		BTSC 	STATUS,2 		//01B2 	1503
		INCR	58H,1 			//01B3 	09D8

		//;rf-out-key.C: 92: conteroutnot=0;
		CLRR 	55H 			//01B4 	0155
		CLRR 	56H 			//01B5 	0156

		//;rf-out-key.C: 93: }
		//;rf-out-key.C: 95: if(PA2!=0 && conteroutnot<=110){
		BTSS 	5H,2 			//01B6 	1D05
		LJUMP 	1C2H 			//01B7 	39C2
		LDWI 	0H 			//01B8 	2A00
		SUBWR 	56H,0 			//01B9 	0C56
		LDWI 	6FH 			//01BA 	2A6F
		BTSC 	STATUS,2 		//01BB 	1503
		SUBWR 	55H,0 			//01BC 	0C55
		BTSC 	STATUS,0 		//01BD 	1403
		LJUMP 	1C2H 			//01BE 	39C2

		//;rf-out-key.C: 96: conteroutnot++;
		INCR	55H,1 			//01BF 	09D5
		BTSC 	STATUS,2 		//01C0 	1503
		INCR	56H,1 			//01C1 	09D6

		//;rf-out-key.C: 97: }
		//;rf-out-key.C: 100: if(PA2==1 && conterout>5 && conterout<15 ){
		BTSS 	5H,2 			//01C2 	1D05
		LJUMP 	1D5H 			//01C3 	39D5
		LDWI 	0H 			//01C4 	2A00
		SUBWR 	58H,0 			//01C5 	0C58
		LDWI 	6H 			//01C6 	2A06
		BTSC 	STATUS,2 		//01C7 	1503
		SUBWR 	57H,0 			//01C8 	0C57
		LDWI 	0H 			//01C9 	2A00
		BTSS 	STATUS,0 		//01CA 	1C03
		LJUMP 	1D6H 			//01CB 	39D6
		SUBWR 	58H,0 			//01CC 	0C58
		LDWI 	FH 			//01CD 	2A0F
		BTSC 	STATUS,2 		//01CE 	1503
		SUBWR 	57H,0 			//01CF 	0C57
		BTSC 	STATUS,0 		//01D0 	1403
		LJUMP 	1D5H 			//01D1 	39D5

		//;rf-out-key.C: 101: conterout++;
		INCR	57H,1 			//01D2 	09D7
		BTSC 	STATUS,2 		//01D3 	1503
		INCR	58H,1 			//01D4 	09D8

		//;rf-out-key.C: 102: }
		//;rf-out-key.C: 104: if(conteroutnot>10 ){
		LDWI 	0H 			//01D5 	2A00
		SUBWR 	56H,0 			//01D6 	0C56
		LDWI 	BH 			//01D7 	2A0B
		BTSC 	STATUS,2 		//01D8 	1503
		SUBWR 	55H,0 			//01D9 	0C55
		BTSS 	STATUS,0 		//01DA 	1C03
		LJUMP 	28AH 			//01DB 	3A8A

		//;rf-out-key.C: 107: if(conterout>53 && conterout<57 ){
		LDWI 	0H 			//01DC 	2A00
		SUBWR 	58H,0 			//01DD 	0C58
		LDWI 	36H 			//01DE 	2A36
		BTSC 	STATUS,2 		//01DF 	1503
		SUBWR 	57H,0 			//01E0 	0C57
		LDWI 	0H 			//01E1 	2A00
		BTSS 	STATUS,0 		//01E2 	1C03
		LJUMP 	206H 			//01E3 	3A06
		SUBWR 	58H,0 			//01E4 	0C58
		LDWI 	39H 			//01E5 	2A39
		BTSC 	STATUS,2 		//01E6 	1503
		SUBWR 	57H,0 			//01E7 	0C57
		BTSC 	STATUS,0 		//01E8 	1403
		LJUMP 	205H 			//01E9 	3A05

		//;rf-out-key.C: 110: if(lastKey==1)conterout=20;
		DECRSZ 	5FH,0 		//01EA 	0E5F
		LJUMP 	1EFH 			//01EB 	39EF
		LDWI 	14H 			//01EC 	2A14
		STR 	57H 			//01ED 	01D7
		CLRR 	58H 			//01EE 	0158

		//;rf-out-key.C: 111: if(lastKey==2)conterout=27;
		LDWI 	2H 			//01EF 	2A02
		XORWR 	5FH,0 			//01F0 	045F
		BTSS 	STATUS,2 		//01F1 	1D03
		LJUMP 	1F6H 			//01F2 	39F6
		LDWI 	1BH 			//01F3 	2A1B
		STR 	57H 			//01F4 	01D7
		CLRR 	58H 			//01F5 	0158

		//;rf-out-key.C: 112: if(lastKey==3)conterout=34;
		LDWI 	3H 			//01F6 	2A03
		XORWR 	5FH,0 			//01F7 	045F
		BTSS 	STATUS,2 		//01F8 	1D03
		LJUMP 	1FDH 			//01F9 	39FD
		LDWI 	22H 			//01FA 	2A22
		STR 	57H 			//01FB 	01D7
		CLRR 	58H 			//01FC 	0158

		//;rf-out-key.C: 113: if(lastKey==4)conterout=41;
		LDWI 	4H 			//01FD 	2A04
		XORWR 	5FH,0 			//01FE 	045F
		BTSS 	STATUS,2 		//01FF 	1D03
		LJUMP 	204H 			//0200 	3A04
		LDWI 	29H 			//0201 	2A29
		STR 	57H 			//0202 	01D7
		CLRR 	58H 			//0203 	0158

		//;rf-out-key.C: 115: LernRFblink=1;
		BSR 	70H,4 			//0204 	1A70

		//;rf-out-key.C: 118: }
		//;rf-out-key.C: 120: if((conterout>18 && conterout<22 ) || O1==1 ){
		LDWI 	0H 			//0205 	2A00
		SUBWR 	58H,0 			//0206 	0C58
		LDWI 	13H 			//0207 	2A13
		BTSC 	STATUS,2 		//0208 	1503
		SUBWR 	57H,0 			//0209 	0C57
		BTSS 	STATUS,0 		//020A 	1C03
		LJUMP 	213H 			//020B 	3A13
		LDWI 	0H 			//020C 	2A00
		SUBWR 	58H,0 			//020D 	0C58
		LDWI 	16H 			//020E 	2A16
		BTSC 	STATUS,2 		//020F 	1503
		SUBWR 	57H,0 			//0210 	0C57
		BTSS 	STATUS,0 		//0211 	1C03
		LJUMP 	215H 			//0212 	3A15
		BTSS 	71H,1 			//0213 	1CF1
		LJUMP 	225H 			//0214 	3A25

		//;rf-out-key.C: 122: if(state1==0){
		BTSC 	77H,3 			//0215 	15F7
		LJUMP 	219H 			//0216 	3A19

		//;rf-out-key.C: 123: state1=1;
		BSR 	77H,3 			//0217 	19F7

		//;rf-out-key.C: 124: }else{
		LJUMP 	21AH 			//0218 	3A1A

		//;rf-out-key.C: 125: state1=0;
		BCR 	77H,3 			//0219 	11F7

		//;rf-out-key.C: 126: }
		//;rf-out-key.C: 128: eerom=1;
		LDWI 	1H 			//021A 	2A01
		STR 	60H 			//021B 	01E0

		//;rf-out-key.C: 129: lastKey=1;
		STR 	5FH 			//021C 	01DF

		//;rf-out-key.C: 130: PA4=state1;
		BTSS 	77H,3 			//021D 	1DF7
		LJUMP 	222H 			//021E 	3A22
		BCR 	STATUS,5 		//021F 	1283
		BSR 	5H,4 			//0220 	1A05
		LJUMP 	224H 			//0221 	3A24
		BCR 	STATUS,5 		//0222 	1283
		BCR 	5H,4 			//0223 	1205

		//;rf-out-key.C: 131: O1=0;
		BCR 	71H,1 			//0224 	10F1

		//;rf-out-key.C: 132: }
		//;rf-out-key.C: 134: if((conterout>25 && conterout<29) || O2==1){
		LDWI 	0H 			//0225 	2A00
		SUBWR 	58H,0 			//0226 	0C58
		LDWI 	1AH 			//0227 	2A1A
		BTSC 	STATUS,2 		//0228 	1503
		SUBWR 	57H,0 			//0229 	0C57
		BTSS 	STATUS,0 		//022A 	1C03
		LJUMP 	233H 			//022B 	3A33
		LDWI 	0H 			//022C 	2A00
		SUBWR 	58H,0 			//022D 	0C58
		LDWI 	1DH 			//022E 	2A1D
		BTSC 	STATUS,2 		//022F 	1503
		SUBWR 	57H,0 			//0230 	0C57
		BTSS 	STATUS,0 		//0231 	1C03
		LJUMP 	235H 			//0232 	3A35
		BTSS 	71H,0 			//0233 	1C71
		LJUMP 	246H 			//0234 	3A46

		//;rf-out-key.C: 136: if(state2==0){
		BTSC 	77H,2 			//0235 	1577
		LJUMP 	239H 			//0236 	3A39

		//;rf-out-key.C: 137: state2=1;
		BSR 	77H,2 			//0237 	1977

		//;rf-out-key.C: 138: }else{
		LJUMP 	23AH 			//0238 	3A3A

		//;rf-out-key.C: 139: state2=0;
		BCR 	77H,2 			//0239 	1177

		//;rf-out-key.C: 140: }
		//;rf-out-key.C: 141: eerom=2;
		LDWI 	2H 			//023A 	2A02
		STR 	60H 			//023B 	01E0

		//;rf-out-key.C: 143: PA0=state2;
		BTSS 	77H,2 			//023C 	1D77
		LJUMP 	241H 			//023D 	3A41
		BCR 	STATUS,5 		//023E 	1283
		BSR 	5H,0 			//023F 	1805
		LJUMP 	243H 			//0240 	3A43
		BCR 	STATUS,5 		//0241 	1283
		BCR 	5H,0 			//0242 	1005

		//;rf-out-key.C: 144: lastKey=2;
		LDWI 	2H 			//0243 	2A02
		STR 	5FH 			//0244 	01DF

		//;rf-out-key.C: 145: O2=0;
		BCR 	71H,0 			//0245 	1071

		//;rf-out-key.C: 146: }
		//;rf-out-key.C: 148: if((conterout>32 && conterout<36 ) || O3==1){
		LDWI 	0H 			//0246 	2A00
		SUBWR 	58H,0 			//0247 	0C58
		LDWI 	21H 			//0248 	2A21
		BTSC 	STATUS,2 		//0249 	1503
		SUBWR 	57H,0 			//024A 	0C57
		BTSS 	STATUS,0 		//024B 	1C03
		LJUMP 	254H 			//024C 	3A54
		LDWI 	0H 			//024D 	2A00
		SUBWR 	58H,0 			//024E 	0C58
		LDWI 	24H 			//024F 	2A24
		BTSC 	STATUS,2 		//0250 	1503
		SUBWR 	57H,0 			//0251 	0C57
		BTSS 	STATUS,0 		//0252 	1C03
		LJUMP 	256H 			//0253 	3A56
		BTSS 	70H,7 			//0254 	1FF0
		LJUMP 	267H 			//0255 	3A67

		//;rf-out-key.C: 150: if(state3==0){
		BTSC 	77H,1 			//0256 	14F7
		LJUMP 	25AH 			//0257 	3A5A

		//;rf-out-key.C: 151: state3=1;
		BSR 	77H,1 			//0258 	18F7

		//;rf-out-key.C: 152: }else{
		LJUMP 	25BH 			//0259 	3A5B

		//;rf-out-key.C: 153: state3=0;
		BCR 	77H,1 			//025A 	10F7

		//;rf-out-key.C: 154: }
		//;rf-out-key.C: 155: eerom=3;
		LDWI 	3H 			//025B 	2A03
		STR 	60H 			//025C 	01E0

		//;rf-out-key.C: 157: PA1=state3;
		BTSS 	77H,1 			//025D 	1CF7
		LJUMP 	262H 			//025E 	3A62
		BCR 	STATUS,5 		//025F 	1283
		BSR 	5H,1 			//0260 	1885
		LJUMP 	264H 			//0261 	3A64
		BCR 	STATUS,5 		//0262 	1283
		BCR 	5H,1 			//0263 	1085

		//;rf-out-key.C: 158: lastKey=3;
		LDWI 	3H 			//0264 	2A03
		STR 	5FH 			//0265 	01DF

		//;rf-out-key.C: 159: O3=0;
		BCR 	70H,7 			//0266 	13F0

		//;rf-out-key.C: 160: }
		//;rf-out-key.C: 162: if((conterout>39 && conterout<43 ) || O4==1){
		LDWI 	0H 			//0267 	2A00
		SUBWR 	58H,0 			//0268 	0C58
		LDWI 	28H 			//0269 	2A28
		BTSC 	STATUS,2 		//026A 	1503
		SUBWR 	57H,0 			//026B 	0C57
		BTSS 	STATUS,0 		//026C 	1C03
		LJUMP 	275H 			//026D 	3A75
		LDWI 	0H 			//026E 	2A00
		SUBWR 	58H,0 			//026F 	0C58
		LDWI 	2BH 			//0270 	2A2B
		BTSC 	STATUS,2 		//0271 	1503
		SUBWR 	57H,0 			//0272 	0C57
		BTSS 	STATUS,0 		//0273 	1C03
		LJUMP 	277H 			//0274 	3A77
		BTSS 	70H,6 			//0275 	1F70
		LJUMP 	288H 			//0276 	3A88

		//;rf-out-key.C: 164: if(state4==0){
		BTSC 	77H,0 			//0277 	1477
		LJUMP 	27BH 			//0278 	3A7B

		//;rf-out-key.C: 165: state4=1;
		BSR 	77H,0 			//0279 	1877

		//;rf-out-key.C: 166: }else{
		LJUMP 	27CH 			//027A 	3A7C

		//;rf-out-key.C: 167: state4=0;
		BCR 	77H,0 			//027B 	1077

		//;rf-out-key.C: 168: }
		//;rf-out-key.C: 169: eerom=4;
		LDWI 	4H 			//027C 	2A04
		STR 	60H 			//027D 	01E0

		//;rf-out-key.C: 171: PA5=state4;
		BTSS 	77H,0 			//027E 	1C77
		LJUMP 	283H 			//027F 	3A83
		BCR 	STATUS,5 		//0280 	1283
		BSR 	5H,5 			//0281 	1A85
		LJUMP 	285H 			//0282 	3A85
		BCR 	STATUS,5 		//0283 	1283
		BCR 	5H,5 			//0284 	1285

		//;rf-out-key.C: 172: lastKey=4;
		LDWI 	4H 			//0285 	2A04
		STR 	5FH 			//0286 	01DF

		//;rf-out-key.C: 173: O4=0;
		BCR 	70H,6 			//0287 	1370

		//;rf-out-key.C: 174: }
		//;rf-out-key.C: 178: conterout=0;
		CLRR 	57H 			//0288 	0157
		CLRR 	58H 			//0289 	0158

		//;rf-out-key.C: 179: }
		//;rf-out-key.C: 185: }
		//;rf-out-key.C: 189: if(TMR2IE && TMR2IF)
		BSR 	STATUS,5 		//028A 	1A83
		BTSS 	CH,1 			//028B 	1C8C
		LJUMP 	309H 			//028C 	3B09
		BCR 	STATUS,5 		//028D 	1283
		BTSS 	CH,1 			//028E 	1C8C
		LJUMP 	309H 			//028F 	3B09

		//;rf-out-key.C: 190: {
		//;rf-out-key.C: 196: TMR2IF = 0;
		BCR 	CH,1 			//0290 	108C
		CLRWDT	 			//0291 	0001

		//;rf-out-key.C: 203: if(PA3==0){
		BCR 	STATUS,5 		//0292 	1283
		BTSC 	5H,3 			//0293 	1585
		LJUMP 	29AH 			//0294 	3A9A

		//;rf-out-key.C: 204: Time++;Frist=1;Timer=0;
		INCR	79H,1 			//0295 	09F9
		BSR 	70H,2 			//0296 	1970
		CLRR 	5BH 			//0297 	015B
		CLRR 	5CH 			//0298 	015C

		//;rf-out-key.C: 205: }
		LJUMP 	309H 			//0299 	3B09

		//;rf-out-key.C: 206: else
		//;rf-out-key.C: 207: {
		//;rf-out-key.C: 209: Timer++;
		INCR	5BH,1 			//029A 	09DB
		BTSC 	STATUS,2 		//029B 	1503
		INCR	5CH,1 			//029C 	09DC

		//;rf-out-key.C: 210: if(Timer>250){Timer=0;Finish=0;}
		LDWI 	0H 			//029D 	2A00
		SUBWR 	5CH,0 			//029E 	0C5C
		LDWI 	FBH 			//029F 	2AFB
		BTSC 	STATUS,2 		//02A0 	1503
		SUBWR 	5BH,0 			//02A1 	0C5B
		BTSS 	STATUS,0 		//02A2 	1C03
		LJUMP 	2A7H 			//02A3 	3AA7
		CLRR 	5BH 			//02A4 	015B
		CLRR 	5CH 			//02A5 	015C
		BCR 	70H,1 			//02A6 	10F0

		//;rf-out-key.C: 211: if(Frist==1 & Finish==0)
		BTSS 	70H,1 			//02A7 	1CF0
		BTSS 	70H,2 			//02A8 	1D70
		LJUMP 	309H 			//02A9 	3B09

		//;rf-out-key.C: 212: {
		//;rf-out-key.C: 213: Timer=0;
		CLRR 	5BH 			//02AA 	015B
		CLRR 	5CH 			//02AB 	015C

		//;rf-out-key.C: 214: if(Start==1)
		BTSS 	70H,5 			//02AC 	1EF0
		LJUMP 	2FCH 			//02AD 	3AFC

		//;rf-out-key.C: 215: {
		//;rf-out-key.C: 216: Bit--;
		DECR 	5DH,1 			//02AE 	0DDD

		//;rf-out-key.C: 217: if(Time>15 & Time< 30)
		LDWI 	10H 			//02AF 	2A10
		SUBWR 	79H,0 			//02B0 	0C79
		BTSS 	STATUS,0 		//02B1 	1C03
		LJUMP 	2BAH 			//02B2 	3ABA
		LDWI 	1EH 			//02B3 	2A1E
		SUBWR 	79H,0 			//02B4 	0C79
		BTSC 	STATUS,0 		//02B5 	1403
		LJUMP 	2BAH 			//02B6 	3ABA

		//;rf-out-key.C: 218: {
		//;rf-out-key.C: 219: Buffer = Buffer << 1;
		BCR 	STATUS,0 		//02B7 	1003
		RLR 	5EH,0 			//02B8 	055E
		STR 	5EH 			//02B9 	01DE

		//;rf-out-key.C: 220: }
		//;rf-out-key.C: 221: if(Time>5 & Time< 12)
		LDWI 	6H 			//02BA 	2A06
		SUBWR 	79H,0 			//02BB 	0C79
		BTSS 	STATUS,0 		//02BC 	1C03
		LJUMP 	2C8H 			//02BD 	3AC8
		LDWI 	CH 			//02BE 	2A0C
		SUBWR 	79H,0 			//02BF 	0C79
		BTSC 	STATUS,0 		//02C0 	1403
		LJUMP 	2C8H 			//02C1 	3AC8

		//;rf-out-key.C: 222: {
		//;rf-out-key.C: 223: Buffer = Buffer << 1;
		BCR 	STATUS,0 		//02C2 	1003
		RLR 	5EH,0 			//02C3 	055E
		STR 	5EH 			//02C4 	01DE

		//;rf-out-key.C: 224: Buffer = Buffer + 1;
		LDR 	5EH,0 			//02C5 	085E
		ADDWI 	1H 			//02C6 	2701
		STR 	5EH 			//02C7 	01DE

		//;rf-out-key.C: 226: }
		//;rf-out-key.C: 227: if(Bit == 0)
		LDR 	5DH,0 			//02C8 	085D
		BTSS 	STATUS,2 		//02C9 	1D03
		LJUMP 	2FCH 			//02CA 	3AFC

		//;rf-out-key.C: 228: {
		//;rf-out-key.C: 229: Bit=8;
		LDWI 	8H 			//02CB 	2A08
		STR 	5DH 			//02CC 	01DD

		//;rf-out-key.C: 230: Data[Count]=RFData[Count];
		LDR 	78H,0 			//02CD 	0878
		ADDWI 	4CH 			//02CE 	274C
		STR 	FSR 			//02CF 	0184
		BCR 	STATUS,7 		//02D0 	1383
		LDR 	INDF,0 			//02D1 	0800
		STR 	72H 			//02D2 	01F2
		LDR 	78H,0 			//02D3 	0878
		ADDWI 	52H 			//02D4 	2752
		STR 	FSR 			//02D5 	0184
		LDR 	72H,0 			//02D6 	0872
		STR 	INDF 			//02D7 	0180

		//;rf-out-key.C: 231: RFData[Count]=Buffer;
		LDR 	78H,0 			//02D8 	0878
		ADDWI 	4CH 			//02D9 	274C
		STR 	FSR 			//02DA 	0184
		LDR 	5EH,0 			//02DB 	085E
		STR 	INDF 			//02DC 	0180

		//;rf-out-key.C: 232: Count++;
		INCR	78H,1 			//02DD 	09F8

		//;rf-out-key.C: 234: if(Count>=3)
		LDWI 	3H 			//02DE 	2A03
		SUBWR 	78H,0 			//02DF 	0C78
		BTSS 	STATUS,0 		//02E0 	1C03
		LJUMP 	2FAH 			//02E1 	3AFA

		//;rf-out-key.C: 235: {
		//;rf-out-key.C: 236: Count=0;
		CLRR 	78H 			//02E2 	0178

		//;rf-out-key.C: 237: Start=0;
		BCR 	70H,5 			//02E3 	12F0

		//;rf-out-key.C: 238: if(Data[0]==RFData[0] && Data[1]==RFData[1] &&Data[2]==RFData[2])
		LDR 	52H,0 			//02E4 	0852
		XORWR 	4CH,0 			//02E5 	044C
		BTSS 	STATUS,2 		//02E6 	1D03
		LJUMP 	2F9H 			//02E7 	3AF9
		LDR 	53H,0 			//02E8 	0853
		XORWR 	4DH,0 			//02E9 	044D
		BTSS 	STATUS,2 		//02EA 	1D03
		LJUMP 	2F9H 			//02EB 	3AF9
		LDR 	54H,0 			//02EC 	0854
		XORWR 	4EH,0 			//02ED 	044E
		BTSS 	STATUS,2 		//02EE 	1D03
		LJUMP 	2F9H 			//02EF 	3AF9

		//;rf-out-key.C: 239: {
		//;rf-out-key.C: 240: DataM[0]=RFData[0];
		LDR 	4CH,0 			//02F0 	084C
		STR 	4FH 			//02F1 	01CF

		//;rf-out-key.C: 241: DataM[1]=RFData[1];
		LDR 	4DH,0 			//02F2 	084D
		STR 	50H 			//02F3 	01D0

		//;rf-out-key.C: 242: DataM[2]=RFData[2];
		LDR 	4EH,0 			//02F4 	084E
		STR 	51H 			//02F5 	01D1

		//;rf-out-key.C: 244: Finish=1;
		BSR 	70H,1 			//02F6 	18F0

		//;rf-out-key.C: 245: Lock=1;
		BSR 	70H,0 			//02F7 	1870

		//;rf-out-key.C: 246: }else
		LJUMP 	2FAH 			//02F8 	3AFA

		//;rf-out-key.C: 247: {
		//;rf-out-key.C: 248: __nop();
		NOP		 					//02F9 	0000

		//;rf-out-key.C: 249: }
		//;rf-out-key.C: 250: }
		//;rf-out-key.C: 251: Buffer=0;
		BCR 	STATUS,5 		//02FA 	1283
		CLRR 	5EH 			//02FB 	015E

		//;rf-out-key.C: 252: }
		//;rf-out-key.C: 253: }
		//;rf-out-key.C: 254: if(Time>120 & Time<250){Start=1;Bit=8;}
		LDWI 	79H 			//02FC 	2A79
		SUBWR 	79H,0 			//02FD 	0C79
		BTSS 	STATUS,0 		//02FE 	1C03
		LJUMP 	307H 			//02FF 	3B07
		LDWI 	FAH 			//0300 	2AFA
		SUBWR 	79H,0 			//0301 	0C79
		BTSC 	STATUS,0 		//0302 	1403
		LJUMP 	307H 			//0303 	3B07
		BSR 	70H,5 			//0304 	1AF0
		LDWI 	8H 			//0305 	2A08
		STR 	5DH 			//0306 	01DD

		//;rf-out-key.C: 255: Frist=0;
		BCR 	70H,2 			//0307 	1170

		//;rf-out-key.C: 256: Time=0;
		CLRR 	79H 			//0308 	0179
		LDR 	75H,0 			//0309 	0875
		STR 	PCLATH 			//030A 	018A
		LDR 	74H,0 			//030B 	0874
		STR 	FSR 			//030C 	0184
		SWAPR 	73H,0 			//030D 	0773
		STR 	STATUS 			//030E 	0183
		SWAPR 	7EH,1 			//030F 	07FE
		SWAPR 	7EH,0 			//0310 	077E
		RETI		 			//0311 	0009

		//;rf-out-key.C: 469: unsigned int a,b;
		//;rf-out-key.C: 470: for(a=0;a<Time;a++)
		CLRR 	65H 			//0312 	0165
		CLRR 	66H 			//0313 	0166
		LDR 	64H,0 			//0314 	0864
		SUBWR 	66H,0 			//0315 	0C66
		BTSS 	STATUS,2 		//0316 	1D03
		LJUMP 	31AH 			//0317 	3B1A
		LDR 	63H,0 			//0318 	0863
		SUBWR 	65H,0 			//0319 	0C65
		BTSC 	STATUS,0 		//031A 	1403
		RET		 					//031B 	0004

		//;rf-out-key.C: 471: {
		//;rf-out-key.C: 472: for(b=0;b<5;b++)
		CLRR 	67H 			//031C 	0167
		CLRR 	68H 			//031D 	0168

		//;rf-out-key.C: 473: {
		//;rf-out-key.C: 474: DelayUs(197);
		LDWI 	C5H 			//031E 	2AC5
		LCALL 	35FH 			//031F 	335F
		INCR	67H,1 			//0320 	09E7
		BTSC 	STATUS,2 		//0321 	1503
		INCR	68H,1 			//0322 	09E8
		LDWI 	0H 			//0323 	2A00
		SUBWR 	68H,0 			//0324 	0C68
		LDWI 	5H 			//0325 	2A05
		BTSC 	STATUS,2 		//0326 	1503
		SUBWR 	67H,0 			//0327 	0C67
		BTSS 	STATUS,0 		//0328 	1C03
		LJUMP 	31EH 			//0329 	3B1E
		INCR	65H,1 			//032A 	09E5
		BTSC 	STATUS,2 		//032B 	1503
		INCR	66H,1 			//032C 	09E6
		LJUMP 	314H 			//032D 	3B14
		STR 	76H 			//032E 	01F6

		//;rf-out-key.C: 446: GIE = 0;
		BCR 	INTCON,7 		//032F 	138B

		//;rf-out-key.C: 447: while(GIE);
		BTSC 	INTCON,7 		//0330 	178B
		LJUMP 	330H 			//0331 	3B30

		//;rf-out-key.C: 448: EEADR = EEAddr;
		LDR 	76H,0 			//0332 	0876
		BSR 	STATUS,5 		//0333 	1A83
		STR 	1BH 			//0334 	019B

		//;rf-out-key.C: 449: EEDAT = Data;
		BCR 	STATUS,5 		//0335 	1283
		LDR 	61H,0 			//0336 	0861
		BSR 	STATUS,5 		//0337 	1A83
		STR 	1AH 			//0338 	019A

		//;rf-out-key.C: 450: EEIF = 0;
		BCR 	STATUS,5 		//0339 	1283
		BCR 	CH,7 			//033A 	138C

		//;rf-out-key.C: 451: EECON1 |= 0x34;
		LDWI 	34H 			//033B 	2A34
		BSR 	STATUS,5 		//033C 	1A83
		IORWR 	1CH,1 			//033D 	039C

		//;rf-out-key.C: 452: WR = 1;
		BSR 	1DH,0 			//033E 	181D

		//;rf-out-key.C: 453: while(WR);
		BTSC 	1DH,0 			//033F 	141D
		LJUMP 	33FH 			//0340 	3B3F

		//;rf-out-key.C: 454: GIE = 1;
		BSR 	INTCON,7 		//0341 	1B8B
		RET		 					//0342 	0004

		//;rf-out-key.C: 395: OSCCON = 0B01110000;
		LDWI 	70H 			//0343 	2A70
		BSR 	STATUS,5 		//0344 	1A83
		STR 	FH 			//0345 	018F

		//;rf-out-key.C: 397: INTCON = 0;
		CLRR 	INTCON 			//0346 	010B

		//;rf-out-key.C: 398: OPTION = 0B00001000;
		LDWI 	8H 			//0347 	2A08
		STR 	1H 			//0348 	0181

		//;rf-out-key.C: 400: PORTA = 0B00000100;
		LDWI 	4H 			//0349 	2A04
		BCR 	STATUS,5 		//034A 	1283
		STR 	5H 			//034B 	0185

		//;rf-out-key.C: 401: TRISA = 0B00001100;
		LDWI 	CH 			//034C 	2A0C
		BSR 	STATUS,5 		//034D 	1A83
		STR 	5H 			//034E 	0185

		//;rf-out-key.C: 403: WPUA = 0B00001100;
		STR 	15H 			//034F 	0195

		//;rf-out-key.C: 405: MSCKCON = 0B00000000;
		BCR 	STATUS,5 		//0350 	1283
		CLRR 	1BH 			//0351 	011B
		RET		 					//0352 	0004

		//;rf-out-key.C: 411: T2CON = 0B00000001;
		LDWI 	1H 			//0353 	2A01
		STR 	12H 			//0354 	0192

		//;rf-out-key.C: 412: TMR2 = 0;
		CLRR 	11H 			//0355 	0111

		//;rf-out-key.C: 413: PR2 = 50;
		LDWI 	32H 			//0356 	2A32
		BSR 	STATUS,5 		//0357 	1A83
		STR 	12H 			//0358 	0192

		//;rf-out-key.C: 414: TMR2IF = 0;
		BCR 	STATUS,5 		//0359 	1283
		BCR 	CH,1 			//035A 	108C

		//;rf-out-key.C: 416: TMR2ON = 1;
		BSR 	12H,2 			//035B 	1912

		//;rf-out-key.C: 417: PEIE=1;
		BSR 	INTCON,6 		//035C 	1B0B

		//;rf-out-key.C: 418: GIE = 1;
		BSR 	INTCON,7 		//035D 	1B8B
		RET		 					//035E 	0004
		STR 	61H 			//035F 	01E1

		//;rf-out-key.C: 459: unsigned char a;
		//;rf-out-key.C: 460: for(a=0;a<Time;a++)
		CLRR 	62H 			//0360 	0162
		LDR 	61H,0 			//0361 	0861
		SUBWR 	62H,0 			//0362 	0C62
		BTSC 	STATUS,0 		//0363 	1403
		RET		 					//0364 	0004

		//;rf-out-key.C: 461: {
		//;rf-out-key.C: 462: __nop();
		NOP		 					//0365 	0000
		CLRWDT	 			//0366 	0001
		BCR 	STATUS,5 		//0367 	1283
		INCR	62H,1 			//0368 	09E2
		LJUMP 	361H 			//0369 	3B61

		//;rf-out-key.C: 423: OPTION = 0B00000110;
		LDWI 	6H 			//036A 	2A06
		BSR 	STATUS,5 		//036B 	1A83
		STR 	1H 			//036C 	0181

		//;rf-out-key.C: 429: TMR0 = 239;
		LDWI 	EFH 			//036D 	2AEF
		BCR 	STATUS,5 		//036E 	1283
		STR 	1H 			//036F 	0181

		//;rf-out-key.C: 430: T0IF = 0;
		BCR 	INTCON,2 		//0370 	110B

		//;rf-out-key.C: 431: T0IE = 1;
		BSR 	INTCON,5 		//0371 	1A8B
		RET		 					//0372 	0004
		BCR 	STATUS,5 		//0373 	1283
		STR 	61H 			//0374 	01E1

		//;rf-out-key.C: 436: unsigned char ReEEPROMread;
		//;rf-out-key.C: 438: EEADR = EEAddr;
		BSR 	STATUS,5 		//0375 	1A83
		STR 	1BH 			//0376 	019B

		//;rf-out-key.C: 439: RD = 1;
		BSR 	1CH,0 			//0377 	181C

		//;rf-out-key.C: 440: ReEEPROMread = EEDAT;
		LDR 	1AH,0 			//0378 	081A
		BCR 	STATUS,5 		//0379 	1283
		STR 	62H 			//037A 	01E2

		//;rf-out-key.C: 441: return ReEEPROMread;
		RET		 					//037B 	0004
		CLRWDT	 			//037C 	0001
		CLRR 	INDF 			//037D 	0100
		INCR	FSR,1 			//037E 	0984
		XORWR 	FSR,0 			//037F 	0404
		BTSC 	STATUS,2 		//0380 	1503
		RETW 	0H 			//0381 	2100
		XORWR 	FSR,0 			//0382 	0404
		LJUMP 	37DH 			//0383 	3B7D
			END
