//Deviec:FT62F21X
//-----------------------Variable---------------------------------
		_PA4		EQU		05H
		_PAIF		EQU		0BH
		_T0IF		EQU		0BH
		_PAIE		EQU		0BH
		_T0IE		EQU		0BH
		_GIE		EQU		0BH
		_TRISA0		EQU		85H
		_TRISA1		EQU		85H
		_TRISA2		EQU		85H
		_TRISA3		EQU		85H
		_TKEN		EQU		86H
		_TKCHGS0		EQU		86H
		_TKCHGS1		EQU		86H
		_LVDEN		EQU		8EH
		_IOCA2		EQU		96H
		_GKeyValue		EQU		67H
		_Last		EQU		66H
		_State		EQU		65H
		_i		EQU		64H
		_Effect		EQU		63H
		_Mute		EQU		62H
		_Flag		EQU		61H
		_Time		EQU		60H
		_Trig		EQU		5FH
		_CountTrig		EQU		5EH
		_Lock		EQU		6DH
		_StartTouchTime		EQU		55H
		_CountKey		EQU		53H
		_awaken		EQU		7AH
		_KeyDv		EQU		5DH
		_charcap		EQU		43H
		_EqudataC		EQU		4BH
		_EquDV		EQU		5CH
		_delta_temp		EQU		5BH
		_DebounceActive		EQU		5AH
		_Touch_Number		EQU		51H
		_UpdataTime		EQU		59H
		_thedeathcount		EQU		4FH
		_Touch_C0		EQU		40H
		_Touch_C1		EQU		41H
		_Touch_Buff		EQU		40H
		_NowKey		EQU		7BH
		_NowKeyCount		EQU		58H
		_DebounceActiveBuff		EQU		57H
		_KEY_FLAG		EQU		42H
		_Keypress		EQU		42H
		_PowerOnD		EQU		42H
		_Level		EQU		42H
		_keyflag		EQU		42H
		_one		EQU		42H
		_KeyOn		EQU		42H
		_KeyOff		EQU		42H
//		Touch_init@x		EQU		79H
//		TouchKeyScan@charcapBuff		EQU		6BH
//		ReadCap4@charcapBuff		EQU		76H
//		ReadCap4@Count		EQU		78H
//		DelayUs2@a		EQU		72H
//		DelayMs@a		EQU		78H
//		DelayMs@Time		EQU		76H
//		Delay_Us@a		EQU		74H
//		Delay_Us@Time		EQU		72H
//-----------------------Variable END---------------------------------

		LJUMP 	0AH 			//0000 	380A
		ORG		0004H
		STR 	7EH 			//0004 	01FE
		SWAPR 	STATUS,0 		//0005 	0703
		STR 	70H 			//0006 	01F0
		LDR 	PCLATH,0 		//0007 	080A
		STR 	71H 			//0008 	01F1
		LJUMP 	299H 			//0009 	3A99
		LJUMP 	0BH 			//000A 	380B
		LDWI 	1H 			//000B 	2A01
		STR 	6DH 			//000C 	01ED
		LDWI 	43H 			//000D 	2A43
		BCR 	STATUS,7 		//000E 	1383
		STR 	FSR 			//000F 	0184
		LDWI 	68H 			//0010 	2A68
		LCALL 	304H 			//0011 	3304
		CLRR 	7BH 			//0012 	017B
		CLRR 	7AH 			//0013 	017A
		CLRR 	STATUS 			//0014 	0103
		LJUMP 	13CH 			//0015 	393C
		INCR	7BH,0 			//0016 	097B
		STR 	68H 			//0017 	01E8
		LDWI 	FH 			//0018 	2A0F
		STR 	69H 			//0019 	01E9
		LDWI 	0H 			//001A 	2A00
		STR 	6AH 			//001B 	01EA
		LJUMP 	20H 			//001C 	3820
		RLR 	6AH,0 			//001D 	056A
		RRR	6AH,1 			//001E 	06EA
		RRR	69H,1 			//001F 	06E9
		DECRSZ 	68H,1 		//0020 	0EE8
		LJUMP 	1DH 			//0021 	381D
		BCR 	STATUS,5 		//0022 	1283
		BTSC 	69H,0 			//0023 	1469
		LJUMP 	2CH 			//0024 	382C
		LDWI 	5H 			//0025 	2A05
		INCR	7BH,1 			//0026 	09FB
		SUBWR 	7BH,0 			//0027 	0C7B
		BTSS 	STATUS,0 		//0028 	1C03
		LJUMP 	16H 			//0029 	3816
		CLRR 	7BH 			//002A 	017B
		LJUMP 	16H 			//002B 	3816
		BCR 	STATUS,0 		//002C 	1003
		LCALL 	137H 			//002D 	3137
		LDR 	INDF,0 			//002E 	0800
		STR 	6BH 			//002F 	01EB
		INCR	FSR,1 			//0030 	0984
		LDR 	INDF,0 			//0031 	0800
		STR 	6CH 			//0032 	01EC
		BTSS 	7AH,0 			//0033 	1C7A
		LJUMP 	37H 			//0034 	3837
		LCALL 	237H 			//0035 	3237
		LJUMP 	38H 			//0036 	3838
		LCALL 	25FH 			//0037 	325F
		CLRR 	5DH 			//0038 	015D
		LDR 	6CH,0 			//0039 	086C
		SUBWR 	52H,0 			//003A 	0C52
		BTSS 	STATUS,2 		//003B 	1D03
		LJUMP 	3FH 			//003C 	383F
		LDR 	6BH,0 			//003D 	086B
		SUBWR 	51H,0 			//003E 	0C51
		BTSC 	STATUS,0 		//003F 	1403
		LJUMP 	55H 			//0040 	3855
		LDR 	51H,0 			//0041 	0851
		SUBWR 	6BH,0 			//0042 	0C6B
		STR 	68H 			//0043 	01E8
		LDR 	52H,0 			//0044 	0852
		BTSS 	STATUS,0 		//0045 	1C03
		INCR	52H,0 			//0046 	0952
		SUBWR 	6CH,0 			//0047 	0C6C
		STR 	69H 			//0048 	01E9
		LDWI 	1H 			//0049 	2A01
		SUBWR 	69H,0 			//004A 	0C69
		LDWI 	0H 			//004B 	2A00
		BTSC 	STATUS,2 		//004C 	1503
		SUBWR 	68H,0 			//004D 	0C68
		BTSS 	STATUS,0 		//004E 	1C03
		LJUMP 	52H 			//004F 	3852
		LDWI 	FFH 			//0050 	2AFF
		LJUMP 	54H 			//0051 	3854
		LDR 	51H,0 			//0052 	0851
		SUBWR 	6BH,0 			//0053 	0C6B
		STR 	5DH 			//0054 	01DD
		BCR 	42H,6 			//0055 	1342
		BCR 	42H,7 			//0056 	13C2
		LDR 	7BH,0 			//0057 	087B
		ADDWI 	1H 			//0058 	2701
		STR 	FSR 			//0059 	0184
		LCALL 	2E9H 			//005A 	32E9
		STR 	68H 			//005B 	01E8
		LDR 	5DH,0 			//005C 	085D
		SUBWR 	68H,0 			//005D 	0C68
		BTSC 	STATUS,0 		//005E 	1403
		BSR 	42H,7 			//005F 	1BC2
		LDR 	7BH,0 			//0060 	087B
		ADDWI 	5H 			//0061 	2705
		STR 	FSR 			//0062 	0184
		LCALL 	2E9H 			//0063 	32E9
		STR 	68H 			//0064 	01E8
		LDR 	5DH,0 			//0065 	085D
		SUBWR 	68H,0 			//0066 	0C68
		BTSS 	STATUS,0 		//0067 	1C03
		BSR 	42H,6 			//0068 	1B42
		LDR 	5AH,0 			//0069 	085A
		STR 	68H 			//006A 	01E8
		INCR	7BH,0 			//006B 	097B
		LJUMP 	6FH 			//006C 	386F
		BCR 	STATUS,0 		//006D 	1003
		RRR	68H,1 			//006E 	06E8
		ADDWI 	FFH 			//006F 	27FF
		BTSS 	STATUS,2 		//0070 	1D03
		LJUMP 	6DH 			//0071 	386D
		BTSS 	68H,0 			//0072 	1C68
		LJUMP 	83H 			//0073 	3883
		BTSS 	42H,7 			//0074 	1FC2
		LJUMP 	97H 			//0075 	3897
		LDWI 	1H 			//0076 	2A01
		STR 	68H 			//0077 	01E8
		INCR	7BH,0 			//0078 	097B
		LJUMP 	7CH 			//0079 	387C
		BCR 	STATUS,0 		//007A 	1003
		RLR 	68H,1 			//007B 	05E8
		ADDWI 	FFH 			//007C 	27FF
		BTSS 	STATUS,2 		//007D 	1D03
		LJUMP 	7AH 			//007E 	387A
		LDR 	68H,0 			//007F 	0868
		XORWI 	FFH 			//0080 	26FF
		ANDWR 	5AH,1 			//0081 	02DA
		LJUMP 	97H 			//0082 	3897
		LDR 	7BH,0 			//0083 	087B
		ADDWI 	5H 			//0084 	2705
		STR 	FSR 			//0085 	0184
		LCALL 	2E9H 			//0086 	32E9
		SUBWR 	5DH,0 			//0087 	0C5D
		BTSC 	STATUS,0 		//0088 	1403
		BCR 	7AH,0 			//0089 	107A
		BTSS 	42H,6 			//008A 	1F42
		LJUMP 	97H 			//008B 	3897
		LDWI 	1H 			//008C 	2A01
		STR 	68H 			//008D 	01E8
		INCR	7BH,0 			//008E 	097B
		LJUMP 	92H 			//008F 	3892
		BCR 	STATUS,0 		//0090 	1003
		RLR 	68H,1 			//0091 	05E8
		ADDWI 	FFH 			//0092 	27FF
		BTSS 	STATUS,2 		//0093 	1D03
		LJUMP 	90H 			//0094 	3890
		LDR 	68H,0 			//0095 	0868
		IORWR 	5AH,1 			//0096 	03DA
		BTSC 	7AH,0 			//0097 	147A
		LJUMP 	F2H 			//0098 	38F2
		BTSS 	42H,1 			//0099 	1CC2
		LJUMP 	9CH 			//009A 	389C
		LCALL 	2F7H 			//009B 	32F7
		LDR 	5AH,0 			//009C 	085A
		BTSS 	STATUS,2 		//009D 	1D03
		LJUMP 	F0H 			//009E 	38F0
		BCR 	STATUS,0 		//009F 	1003
		LCALL 	137H 			//00A0 	3137
		LCALL 	126H 			//00A1 	3126
		BTSC 	STATUS,0 		//00A2 	1403
		LJUMP 	A8H 			//00A3 	38A8
		LCALL 	132H 			//00A4 	3132
		LDR 	INDF,0 			//00A5 	0800
		SUBWR 	51H,0 			//00A6 	0C51
		STR 	5CH 			//00A7 	01DC
		LDR 	7BH,0 			//00A8 	087B
		ADDWI 	5H 			//00A9 	2705
		STR 	FSR 			//00AA 	0184
		LCALL 	2E9H 			//00AB 	32E9
		STR 	68H 			//00AC 	01E8
		BCR 	STATUS,0 		//00AD 	1003
		RRR	68H,0 			//00AE 	0668
		SUBWR 	5CH,0 			//00AF 	0C5C
		LDR 	58H,0 			//00B0 	0858
		BTSS 	STATUS,0 		//00B1 	1C03
		LJUMP 	C3H 			//00B2 	38C3
		ADDWI 	4BH 			//00B3 	274B
		STR 	FSR 			//00B4 	0184
		INCR	INDF,1 			//00B5 	0980
		LDR 	58H,0 			//00B6 	0858
		ADDWI 	4BH 			//00B7 	274B
		STR 	FSR 			//00B8 	0184
		LDWI 	6H 			//00B9 	2A06
		SUBWR 	INDF,0 		//00BA 	0C00
		BTSS 	STATUS,0 		//00BB 	1C03
		LJUMP 	C6H 			//00BC 	38C6
		LCALL 	2FEH 			//00BD 	32FE
		STR 	INDF 			//00BE 	0180
		INCR	FSR,1 			//00BF 	0984
		LDR 	52H,0 			//00C0 	0852
		STR 	INDF 			//00C1 	0180
		LDR 	58H,0 			//00C2 	0858
		ADDWI 	4BH 			//00C3 	274B
		STR 	FSR 			//00C4 	0184
		CLRR 	INDF 			//00C5 	0100
		LDWI 	3H 			//00C6 	2A03
		CLRR 	4FH 			//00C7 	014F
		CLRR 	50H 			//00C8 	0150
		XORWR 	59H,0 			//00C9 	0459
		BTSS 	STATUS,2 		//00CA 	1D03
		LJUMP 	10CH 			//00CB 	390C
		LCALL 	132H 			//00CC 	3132
		LCALL 	126H 			//00CD 	3126
		BTSC 	STATUS,0 		//00CE 	1403
		LJUMP 	DAH 			//00CF 	38DA
		BCR 	STATUS,0 		//00D0 	1003
		RLR 	58H,0 			//00D1 	0558
		ADDWI 	43H 			//00D2 	2743
		STR 	FSR 			//00D3 	0184
		LDWI 	1H 			//00D4 	2A01
		ADDWR 	INDF,1 		//00D5 	0B80
		INCR	FSR,1 			//00D6 	0984
		BTSC 	STATUS,0 		//00D7 	1403
		INCR	INDF,1 			//00D8 	0980
		LJUMP 	10CH 			//00D9 	390C
		LCALL 	132H 			//00DA 	3132
		LDR 	INDF,0 			//00DB 	0800
		STR 	68H 			//00DC 	01E8
		INCR	FSR,1 			//00DD 	0984
		LDR 	INDF,0 			//00DE 	0800
		STR 	69H 			//00DF 	01E9
		IORWR 	68H,0 			//00E0 	0368
		BTSC 	STATUS,2 		//00E1 	1503
		LJUMP 	10CH 			//00E2 	390C
		BCR 	STATUS,0 		//00E3 	1003
		RLR 	58H,0 			//00E4 	0558
		ADDWI 	43H 			//00E5 	2743
		STR 	FSR 			//00E6 	0184
		LDWI 	1H 			//00E7 	2A01
		SUBWR 	INDF,1 		//00E8 	0C80
		INCRSZ 	FSR,1 		//00E9 	0A84
		LDWI 	0H 			//00EA 	2A00
		BTSS 	STATUS,0 		//00EB 	1C03
		DECR 	INDF,1 			//00EC 	0D80
		SUBWR 	INDF,1 		//00ED 	0C80
		DECR 	FSR,1 			//00EE 	0D84
		LJUMP 	10CH 			//00EF 	390C
		CLRR 	59H 			//00F0 	0159
		LJUMP 	10CH 			//00F1 	390C
		LDWI 	28H 			//00F2 	2A28
		INCR	5BH,1 			//00F3 	09DB
		SUBWR 	5BH,0 			//00F4 	0C5B
		BTSS 	STATUS,0 		//00F5 	1C03
		LJUMP 	102H 			//00F6 	3902
		LDWI 	2CH 			//00F7 	2A2C
		SUBWR 	5BH,0 			//00F8 	0C5B
		BTSS 	STATUS,0 		//00F9 	1C03
		LJUMP 	FDH 			//00FA 	38FD
		CLRR 	5BH 			//00FB 	015B
		BCR 	STATUS,0 		//00FC 	1003
		LCALL 	137H 			//00FD 	3137
		LCALL 	126H 			//00FE 	3126
		BTSS 	STATUS,0 		//00FF 	1C03
		LJUMP 	D1H 			//0100 	38D1
		LJUMP 	DAH 			//0101 	38DA
		LDR 	52H,0 			//0102 	0852
		SUBWR 	6CH,0 			//0103 	0C6C
		BTSS 	STATUS,2 		//0104 	1D03
		LJUMP 	108H 			//0105 	3908
		LDR 	51H,0 			//0106 	0851
		SUBWR 	6BH,0 			//0107 	0C6B
		BTSC 	STATUS,0 		//0108 	1403
		LJUMP 	10CH 			//0109 	390C
		LDWI 	28H 			//010A 	2A28
		STR 	5BH 			//010B 	01DB
		LDWI 	4H 			//010C 	2A04
		INCR	58H,1 			//010D 	09D8
		SUBWR 	58H,0 			//010E 	0C58
		BTSS 	STATUS,0 		//010F 	1C03
		LJUMP 	123H 			//0110 	3923
		LDWI 	4H 			//0111 	2A04
		SUBWR 	59H,0 			//0112 	0C59
		BTSS 	STATUS,0 		//0113 	1C03
		LJUMP 	116H 			//0114 	3916
		CLRR 	59H 			//0115 	0159
		LDR 	4FH,0 			//0116 	084F
		IORWR 	50H,0 			//0117 	0350
		BTSC 	STATUS,2 		//0118 	1503
		LJUMP 	11CH 			//0119 	391C
		CLRR 	4FH 			//011A 	014F
		CLRR 	50H 			//011B 	0150
		INCR	59H,1 			//011C 	09D9
		INCR	4FH,1 			//011D 	09CF
		BTSC 	STATUS,2 		//011E 	1503
		INCR	50H,1 			//011F 	09D0
		CLRR 	58H 			//0120 	0158
		LDR 	5AH,0 			//0121 	085A
		STR 	57H 			//0122 	01D7
		INCR	7BH,1 			//0123 	09FB
		LDR 	57H,0 			//0124 	0857
		RET		 					//0125 	0004
		LDR 	INDF,0 			//0126 	0800
		STR 	68H 			//0127 	01E8
		INCR	FSR,1 			//0128 	0984
		LDR 	INDF,0 			//0129 	0800
		STR 	69H 			//012A 	01E9
		LDR 	52H,0 			//012B 	0852
		SUBWR 	69H,0 			//012C 	0C69
		BTSS 	STATUS,2 		//012D 	1D03
		RET		 					//012E 	0004
		LDR 	51H,0 			//012F 	0851
		SUBWR 	68H,0 			//0130 	0C68
		RET		 					//0131 	0004
		BCR 	STATUS,0 		//0132 	1003
		RLR 	58H,0 			//0133 	0558
		ADDWI 	43H 			//0134 	2743
		STR 	FSR 			//0135 	0184
		RET		 					//0136 	0004
		RLR 	58H,0 			//0137 	0558
		ADDWI 	43H 			//0138 	2743
		STR 	FSR 			//0139 	0184
		BCR 	STATUS,7 		//013A 	1383
		RET		 					//013B 	0004

		//;main.c: 246: TRISA = 0B00000000;
		BSR 	STATUS,5 		//013C 	1A83
		CLRR 	5H 			//013D 	0105

		//;main.c: 247: PORTA = 0B00000000;
		BCR 	STATUS,5 		//013E 	1283
		CLRR 	5H 			//013F 	0105

		//;main.c: 249: PA4=1;__nop();;
		BSR 	5H,4 			//0140 	1A05
		NOP		 					//0141 	0000

		//;main.c: 251: SYS_INITIAL();
		LCALL 	27EH 			//0142 	327E

		//;main.c: 253: DelayMs(200);
		LDWI 	C8H 			//0143 	2AC8
		STR 	76H 			//0144 	01F6
		CLRR 	77H 			//0145 	0177
		LCALL 	2C6H 			//0146 	32C6

		//;main.c: 255: TIMER0_INITIAL();
		LCALL 	31BH 			//0147 	331B

		//;main.c: 256: Touch_init();
		LCALL 	2B2H 			//0148 	32B2

		//;main.c: 261: {
		//;main.c: 262: Delay_Us(10);
		LDWI 	AH 			//0149 	2A0A
		STR 	72H 			//014A 	01F2
		CLRR 	73H 			//014B 	0173
		LCALL 	2D9H 			//014C 	32D9

		//;main.c: 263: if(StartTouchTime >= (2500/12/4))
		LDWI 	0H 			//014D 	2A00
		BCR 	STATUS,5 		//014E 	1283
		SUBWR 	56H,0 			//014F 	0C56
		LDWI 	34H 			//0150 	2A34
		BTSC 	STATUS,2 		//0151 	1503
		SUBWR 	55H,0 			//0152 	0C55
		BTSS 	STATUS,0 		//0153 	1C03
		LJUMP 	159H 			//0154 	3959

		//;main.c: 264: {
		//;main.c: 265: StartTouchTime = 0;
		CLRR 	55H 			//0155 	0155
		CLRR 	56H 			//0156 	0156

		//;main.c: 266: GKeyValue = TouchKeyScan();
		LCALL 	16H 			//0157 	3016
		STR 	67H 			//0158 	01E7

		//;main.c: 267: }
		//;main.c: 268: if(GKeyValue!=0)
		LDR 	67H,0 			//0159 	0867
		BTSC 	STATUS,2 		//015A 	1503
		LJUMP 	228H 			//015B 	3A28

		//;main.c: 269: {
		//;main.c: 271: if(GKeyValue==8)
		LDWI 	8H 			//015C 	2A08
		XORWR 	67H,0 			//015D 	0467
		BTSS 	STATUS,2 		//015E 	1D03
		LJUMP 	188H 			//015F 	3988

		//;main.c: 272: {
		//;main.c: 273: if(CountKey<305)
		LDWI 	1H 			//0160 	2A01
		SUBWR 	54H,0 			//0161 	0C54
		LDWI 	31H 			//0162 	2A31
		BTSC 	STATUS,2 		//0163 	1503
		SUBWR 	53H,0 			//0164 	0C53
		BTSC 	STATUS,0 		//0165 	1403
		LJUMP 	188H 			//0166 	3988

		//;main.c: 274: {
		//;main.c: 275: CountKey++;
		//;main.c: 276: if(CountKey>300)
		LCALL 	22CH 			//0167 	322C
		BTSC 	STATUS,2 		//0168 	1503
		SUBWR 	53H,0 			//0169 	0C53
		BTSS 	STATUS,0 		//016A 	1C03
		LJUMP 	188H 			//016B 	3988

		//;main.c: 277: {
		//;main.c: 278: CountKey=310;
		LCALL 	232H 			//016C 	3232

		//;main.c: 279: PA4=0;__nop();;
		BCR 	5H,4 			//016D 	1205
		NOP		 					//016E 	0000

		//;main.c: 280: DelayMs(1);
		CLRR 	76H 			//016F 	0176
		INCR	76H,1 			//0170 	09F6
		CLRR 	77H 			//0171 	0177
		LCALL 	2C6H 			//0172 	32C6

		//;main.c: 282: PA4=1;__nop();;
		BCR 	STATUS,5 		//0173 	1283
		BSR 	5H,4 			//0174 	1A05
		NOP		 					//0175 	0000

		//;main.c: 283: DelayMs(1);
		CLRR 	76H 			//0176 	0176
		INCR	76H,1 			//0177 	09F6
		CLRR 	77H 			//0178 	0177
		LCALL 	2C6H 			//0179 	32C6

		//;main.c: 285: PA4=0;__nop();;
		BCR 	STATUS,5 		//017A 	1283
		BCR 	5H,4 			//017B 	1205
		NOP		 					//017C 	0000

		//;main.c: 286: DelayMs(1);
		CLRR 	76H 			//017D 	0176
		INCR	76H,1 			//017E 	09F6
		CLRR 	77H 			//017F 	0177
		LCALL 	2C6H 			//0180 	32C6

		//;main.c: 287: PA4=1;__nop();;
		BCR 	STATUS,5 		//0181 	1283
		BSR 	5H,4 			//0182 	1A05
		NOP		 					//0183 	0000

		//;main.c: 289: DelayMs(20);
		LDWI 	14H 			//0184 	2A14
		STR 	76H 			//0185 	01F6
		CLRR 	77H 			//0186 	0177
		LCALL 	2C6H 			//0187 	32C6

		//;main.c: 291: }
		//;main.c: 292: }
		//;main.c: 293: }
		//;main.c: 295: if(GKeyValue==1)
		BCR 	STATUS,5 		//0188 	1283
		DECRSZ 	67H,0 		//0189 	0E67
		LJUMP 	1B3H 			//018A 	39B3

		//;main.c: 296: {
		//;main.c: 297: if(CountKey<305)
		LDWI 	1H 			//018B 	2A01
		SUBWR 	54H,0 			//018C 	0C54
		LDWI 	31H 			//018D 	2A31
		BTSC 	STATUS,2 		//018E 	1503
		SUBWR 	53H,0 			//018F 	0C53
		BTSC 	STATUS,0 		//0190 	1403
		LJUMP 	1B3H 			//0191 	39B3

		//;main.c: 298: {
		//;main.c: 299: CountKey++;
		//;main.c: 300: if(CountKey>300)
		LCALL 	22CH 			//0192 	322C
		BTSC 	STATUS,2 		//0193 	1503
		SUBWR 	53H,0 			//0194 	0C53
		BTSS 	STATUS,0 		//0195 	1C03
		LJUMP 	1B3H 			//0196 	39B3

		//;main.c: 301: {
		//;main.c: 302: CountKey=310;
		LCALL 	232H 			//0197 	3232

		//;main.c: 304: PA4=0;__nop();;
		BCR 	5H,4 			//0198 	1205
		NOP		 					//0199 	0000

		//;main.c: 305: DelayMs(1);
		CLRR 	76H 			//019A 	0176
		INCR	76H,1 			//019B 	09F6
		CLRR 	77H 			//019C 	0177
		LCALL 	2C6H 			//019D 	32C6

		//;main.c: 307: PA4=1;__nop();;
		BCR 	STATUS,5 		//019E 	1283
		BSR 	5H,4 			//019F 	1A05
		NOP		 					//01A0 	0000

		//;main.c: 308: DelayMs(1);
		CLRR 	76H 			//01A1 	0176
		INCR	76H,1 			//01A2 	09F6
		CLRR 	77H 			//01A3 	0177
		LCALL 	2C6H 			//01A4 	32C6

		//;main.c: 310: PA4=0;__nop();;
		BCR 	STATUS,5 		//01A5 	1283
		BCR 	5H,4 			//01A6 	1205
		NOP		 					//01A7 	0000

		//;main.c: 311: DelayMs(2);
		LDWI 	2H 			//01A8 	2A02
		STR 	76H 			//01A9 	01F6
		CLRR 	77H 			//01AA 	0177
		LCALL 	2C6H 			//01AB 	32C6

		//;main.c: 312: PA4=1;__nop();;
		BCR 	STATUS,5 		//01AC 	1283
		BSR 	5H,4 			//01AD 	1A05
		NOP		 					//01AE 	0000

		//;main.c: 314: DelayMs(20);
		LDWI 	14H 			//01AF 	2A14
		STR 	76H 			//01B0 	01F6
		CLRR 	77H 			//01B1 	0177
		LCALL 	2C6H 			//01B2 	32C6

		//;main.c: 316: }
		//;main.c: 317: }
		//;main.c: 318: }
		//;main.c: 320: if(GKeyValue==2)
		LDWI 	2H 			//01B3 	2A02
		BCR 	STATUS,5 		//01B4 	1283
		XORWR 	67H,0 			//01B5 	0467
		BTSS 	STATUS,2 		//01B6 	1D03
		LJUMP 	1E0H 			//01B7 	39E0

		//;main.c: 321: {
		//;main.c: 322: if(CountKey<305)
		LDWI 	1H 			//01B8 	2A01
		SUBWR 	54H,0 			//01B9 	0C54
		LDWI 	31H 			//01BA 	2A31
		BTSC 	STATUS,2 		//01BB 	1503
		SUBWR 	53H,0 			//01BC 	0C53
		BTSC 	STATUS,0 		//01BD 	1403
		LJUMP 	1E0H 			//01BE 	39E0

		//;main.c: 323: {
		//;main.c: 324: CountKey++;
		//;main.c: 325: if(CountKey>300)
		LCALL 	22CH 			//01BF 	322C
		BTSC 	STATUS,2 		//01C0 	1503
		SUBWR 	53H,0 			//01C1 	0C53
		BTSS 	STATUS,0 		//01C2 	1C03
		LJUMP 	1E0H 			//01C3 	39E0

		//;main.c: 326: {
		//;main.c: 327: CountKey=310;
		LCALL 	232H 			//01C4 	3232

		//;main.c: 330: PA4=0;__nop();;
		BCR 	5H,4 			//01C5 	1205
		NOP		 					//01C6 	0000

		//;main.c: 331: DelayMs(1);
		CLRR 	76H 			//01C7 	0176
		INCR	76H,1 			//01C8 	09F6
		CLRR 	77H 			//01C9 	0177
		LCALL 	2C6H 			//01CA 	32C6

		//;main.c: 333: PA4=1;__nop();;
		BCR 	STATUS,5 		//01CB 	1283
		BSR 	5H,4 			//01CC 	1A05
		NOP		 					//01CD 	0000

		//;main.c: 334: DelayMs(1);
		CLRR 	76H 			//01CE 	0176
		INCR	76H,1 			//01CF 	09F6
		CLRR 	77H 			//01D0 	0177
		LCALL 	2C6H 			//01D1 	32C6

		//;main.c: 336: PA4=0;__nop();;
		BCR 	STATUS,5 		//01D2 	1283
		BCR 	5H,4 			//01D3 	1205
		NOP		 					//01D4 	0000

		//;main.c: 337: DelayMs(3);
		LDWI 	3H 			//01D5 	2A03
		STR 	76H 			//01D6 	01F6
		CLRR 	77H 			//01D7 	0177
		LCALL 	2C6H 			//01D8 	32C6

		//;main.c: 338: PA4=1;__nop();;
		BCR 	STATUS,5 		//01D9 	1283
		BSR 	5H,4 			//01DA 	1A05
		NOP		 					//01DB 	0000

		//;main.c: 340: DelayMs(20);
		LDWI 	14H 			//01DC 	2A14
		STR 	76H 			//01DD 	01F6
		CLRR 	77H 			//01DE 	0177
		LCALL 	2C6H 			//01DF 	32C6

		//;main.c: 342: }
		//;main.c: 343: }
		//;main.c: 344: }
		//;main.c: 347: if(GKeyValue==4)
		LDWI 	4H 			//01E0 	2A04
		BCR 	STATUS,5 		//01E1 	1283
		XORWR 	67H,0 			//01E2 	0467
		BTSS 	STATUS,2 		//01E3 	1D03
		LJUMP 	20DH 			//01E4 	3A0D

		//;main.c: 348: {
		//;main.c: 349: if(CountKey<305)
		LDWI 	1H 			//01E5 	2A01
		SUBWR 	54H,0 			//01E6 	0C54
		LDWI 	31H 			//01E7 	2A31
		BTSC 	STATUS,2 		//01E8 	1503
		SUBWR 	53H,0 			//01E9 	0C53
		BTSC 	STATUS,0 		//01EA 	1403
		LJUMP 	20DH 			//01EB 	3A0D

		//;main.c: 350: {
		//;main.c: 351: CountKey++;
		//;main.c: 352: if(CountKey>300)
		LCALL 	22CH 			//01EC 	322C
		BTSC 	STATUS,2 		//01ED 	1503
		SUBWR 	53H,0 			//01EE 	0C53
		BTSS 	STATUS,0 		//01EF 	1C03
		LJUMP 	20DH 			//01F0 	3A0D

		//;main.c: 353: {
		//;main.c: 354: CountKey=310;
		LCALL 	232H 			//01F1 	3232

		//;main.c: 357: PA4=0;__nop();;
		BCR 	5H,4 			//01F2 	1205
		NOP		 					//01F3 	0000

		//;main.c: 358: DelayMs(1);
		CLRR 	76H 			//01F4 	0176
		INCR	76H,1 			//01F5 	09F6
		CLRR 	77H 			//01F6 	0177
		LCALL 	2C6H 			//01F7 	32C6

		//;main.c: 360: PA4=1;__nop();;
		BCR 	STATUS,5 		//01F8 	1283
		BSR 	5H,4 			//01F9 	1A05
		NOP		 					//01FA 	0000

		//;main.c: 361: DelayMs(1);
		CLRR 	76H 			//01FB 	0176
		INCR	76H,1 			//01FC 	09F6
		CLRR 	77H 			//01FD 	0177
		LCALL 	2C6H 			//01FE 	32C6

		//;main.c: 363: PA4=0;__nop();;
		BCR 	STATUS,5 		//01FF 	1283
		BCR 	5H,4 			//0200 	1205
		NOP		 					//0201 	0000

		//;main.c: 364: DelayMs(4);
		LDWI 	4H 			//0202 	2A04
		STR 	76H 			//0203 	01F6
		CLRR 	77H 			//0204 	0177
		LCALL 	2C6H 			//0205 	32C6

		//;main.c: 365: PA4=1;__nop();;
		BCR 	STATUS,5 		//0206 	1283
		BSR 	5H,4 			//0207 	1A05
		NOP		 					//0208 	0000

		//;main.c: 367: DelayMs(20);
		LDWI 	14H 			//0209 	2A14
		STR 	76H 			//020A 	01F6
		CLRR 	77H 			//020B 	0177
		LCALL 	2C6H 			//020C 	32C6

		//;main.c: 371: }
		//;main.c: 372: }
		//;main.c: 373: }
		//;main.c: 376: if(Last!=GKeyValue)
		BCR 	STATUS,5 		//020D 	1283
		LDR 	66H,0 			//020E 	0866
		XORWR 	67H,0 			//020F 	0467
		BTSC 	STATUS,2 		//0210 	1503
		LJUMP 	224H 			//0211 	3A24

		//;main.c: 377: {
		//;main.c: 378: if(GKeyValue==1)
		DECRSZ 	67H,0 		//0212 	0E67
		LJUMP 	215H 			//0213 	3A15

		//;main.c: 379: {
		//;main.c: 380: __nop();
		NOP		 					//0214 	0000

		//;main.c: 382: }
		//;main.c: 383: if(GKeyValue==2)
		LDWI 	2H 			//0215 	2A02
		BCR 	STATUS,5 		//0216 	1283
		XORWR 	67H,0 			//0217 	0467
		BTSC 	STATUS,2 		//0218 	1503

		//;main.c: 384: {
		//;main.c: 385: __nop();
		NOP		 					//0219 	0000

		//;main.c: 387: }
		//;main.c: 388: if(GKeyValue==4)
		LDWI 	4H 			//021A 	2A04
		BCR 	STATUS,5 		//021B 	1283
		XORWR 	67H,0 			//021C 	0467
		BTSC 	STATUS,2 		//021D 	1503

		//;main.c: 389: {
		//;main.c: 390: __nop();
		NOP		 					//021E 	0000

		//;main.c: 392: }
		//;main.c: 393: if(GKeyValue==8)
		LDWI 	8H 			//021F 	2A08
		BCR 	STATUS,5 		//0220 	1283
		XORWR 	67H,0 			//0221 	0467
		BTSC 	STATUS,2 		//0222 	1503

		//;main.c: 394: {
		//;main.c: 395: __nop();
		NOP		 					//0223 	0000

		//;main.c: 397: }
		//;main.c: 398: }
		//;main.c: 399: Last=GKeyValue;
		BCR 	STATUS,5 		//0224 	1283
		LDR 	67H,0 			//0225 	0867
		STR 	66H 			//0226 	01E6

		//;main.c: 401: }
		LJUMP 	149H 			//0227 	3949

		//;main.c: 402: else
		//;main.c: 403: {
		//;main.c: 404: Last=0;
		CLRR 	66H 			//0228 	0166

		//;main.c: 409: }
		//;main.c: 410: CountKey=0;
		CLRR 	53H 			//0229 	0153
		CLRR 	54H 			//022A 	0154
		LJUMP 	149H 			//022B 	3949
		INCR	53H,1 			//022C 	09D3
		BTSC 	STATUS,2 		//022D 	1503
		INCR	54H,1 			//022E 	09D4
		LDWI 	1H 			//022F 	2A01
		SUBWR 	54H,0 			//0230 	0C54
		RETW 	2DH 			//0231 	212D
		LDWI 	36H 			//0232 	2A36
		STR 	53H 			//0233 	01D3
		LDWI 	1H 			//0234 	2A01
		STR 	54H 			//0235 	01D4
		RET		 					//0236 	0004
		BSR 	STATUS,5 		//0237 	1A83
		BCR 	6H,6 			//0238 	1306
		BSR 	6H,5 			//0239 	1A86
		BSR 	6H,4 			//023A 	1A06
		LCALL 	30CH 			//023B 	330C
		LCALL 	314H 			//023C 	3314
		BSR 	6H,4 			//023D 	1A06
		LCALL 	30CH 			//023E 	330C
		BSR 	STATUS,5 		//023F 	1A83
		BCR 	6H,4 			//0240 	1206
		BSR 	6H,5 			//0241 	1A86
		BCR 	6H,6 			//0242 	1306
		LDWI 	1H 			//0243 	2A01
		STR 	73H 			//0244 	01F3
		INCR	7BH,0 			//0245 	097B
		LJUMP 	249H 			//0246 	3A49
		BCR 	STATUS,0 		//0247 	1003
		RLR 	73H,1 			//0248 	05F3
		ADDWI 	FFH 			//0249 	27FF
		BTSS 	STATUS,2 		//024A 	1D03
		LJUMP 	247H 			//024B 	3A47
		LDR 	73H,0 			//024C 	0873
		IORWR 	6H,1 			//024D 	0386
		BSR 	STATUS,5 		//024E 	1A83
		INCR	40H,1 			//024F 	09C0
		BTSC 	STATUS,2 		//0250 	1503
		INCR	41H,1 			//0251 	09C1
		BSR 	6H,6 			//0252 	1B06
		BSR 	6H,4 			//0253 	1A06
		BCR 	6H,4 			//0254 	1206
		BCR 	6H,6 			//0255 	1306
		BTSC 	EH,2 			//0256 	150E
		LJUMP 	24FH 			//0257 	3A4F
		LCALL 	322H 			//0258 	3322
		BCR 	STATUS,5 		//0259 	1283
		LDR 	41H,0 			//025A 	0841
		STR 	52H 			//025B 	01D2
		LDR 	40H,0 			//025C 	0840
		STR 	51H 			//025D 	01D1
		RET		 					//025E 	0004
		CLRR 	76H 			//025F 	0176
		CLRR 	77H 			//0260 	0177
		CLRR 	78H 			//0261 	0178
		CLRWDT	 			//0262 	0001
		LCALL 	237H 			//0263 	3237
		LDR 	40H,0 			//0264 	0840
		ADDWR 	76H,1 			//0265 	0BF6
		BTSC 	STATUS,0 		//0266 	1403
		INCR	77H,1 			//0267 	09F7
		LDR 	41H,0 			//0268 	0841
		ADDWR 	77H,1 			//0269 	0BF7
		LDWI 	4H 			//026A 	2A04
		INCR	78H,1 			//026B 	09F8
		SUBWR 	78H,0 			//026C 	0C78
		BTSS 	STATUS,0 		//026D 	1C03
		LJUMP 	262H 			//026E 	3A62
		LDR 	77H,0 			//026F 	0877
		STR 	75H 			//0270 	01F5
		LDR 	76H,0 			//0271 	0876
		STR 	74H 			//0272 	01F4
		BCR 	STATUS,0 		//0273 	1003
		RRR	75H,1 			//0274 	06F5
		RRR	74H,1 			//0275 	06F4
		BCR 	STATUS,0 		//0276 	1003
		RRR	75H,1 			//0277 	06F5
		RRR	74H,1 			//0278 	06F4
		LDR 	74H,0 			//0279 	0874
		STR 	51H 			//027A 	01D1
		LDR 	75H,0 			//027B 	0875
		STR 	52H 			//027C 	01D2
		RET		 					//027D 	0004

		//;main.c: 193: OSCCON = 0B01100000;
		LDWI 	60H 			//027E 	2A60
		BSR 	STATUS,5 		//027F 	1A83
		STR 	FH 			//0280 	018F

		//;main.c: 194: OPTION = 0B00000100;
		LDWI 	4H 			//0281 	2A04
		STR 	1H 			//0282 	0181

		//;main.c: 195: TRISA = 0B00000000;
		CLRR 	5H 			//0283 	0105

		//;main.c: 196: PORTA = 0B00000000;
		BCR 	STATUS,5 		//0284 	1283
		CLRR 	5H 			//0285 	0105

		//;main.c: 197: LVDCON = 0x03;
		LDWI 	3H 			//0286 	2A03
		BSR 	STATUS,5 		//0287 	1A83
		STR 	DH 			//0288 	018D

		//;main.c: 198: PCON = 0x88;
		LDWI 	88H 			//0289 	2A88
		STR 	EH 			//028A 	018E

		//;main.c: 199: TRISA = 0B00000000;
		CLRR 	5H 			//028B 	0105

		//;main.c: 200: PORTA = 0B00000000;
		BCR 	STATUS,5 		//028C 	1283
		CLRR 	5H 			//028D 	0105

		//;main.c: 201: OSCCON = 0B01110000;
		LDWI 	70H 			//028E 	2A70
		BSR 	STATUS,5 		//028F 	1A83
		STR 	FH 			//0290 	018F

		//;main.c: 202: INTCON = 0;
		CLRR 	INTCON 			//0291 	010B

		//;main.c: 204: PORTA = 0B00000000;
		BCR 	STATUS,5 		//0292 	1283
		CLRR 	5H 			//0293 	0105

		//;main.c: 205: TRISA = 0B00000000;
		BSR 	STATUS,5 		//0294 	1A83
		CLRR 	5H 			//0295 	0105

		//;main.c: 206: WPUA = 0B00000000;
		CLRR 	15H 			//0296 	0115

		//;main.c: 207: PSRCA = 0B00000000;
		CLRR 	8H 			//0297 	0108
		RET		 					//0298 	0004

		//;main.c: 42: if(T0IE && T0IF)
		BTSC 	INTCON,5 		//0299 	168B
		BTSS 	INTCON,2 		//029A 	1D0B
		LJUMP 	2A3H 			//029B 	3AA3

		//;main.c: 43: {
		//;main.c: 44: T0IF = 0;
		BCR 	INTCON,2 		//029C 	110B

		//;main.c: 45: TMR0 = 206;
		LDWI 	CEH 			//029D 	2ACE
		BCR 	STATUS,5 		//029E 	1283
		STR 	1H 			//029F 	0181

		//;main.c: 46: StartTouchTime++;
		INCR	55H,1 			//02A0 	09D5
		BTSC 	STATUS,2 		//02A1 	1503
		INCR	56H,1 			//02A2 	09D6

		//;main.c: 131: }
		//;main.c: 133: if(PAIE && PAIF)
		BTSC 	INTCON,3 		//02A3 	158B
		BTSS 	INTCON,0 		//02A4 	1C0B
		LJUMP 	2ABH 			//02A5 	3AAB

		//;main.c: 134: {
		//;main.c: 156: ReadAPin = PORTA;
		BCR 	STATUS,5 		//02A6 	1283
		LDR 	5H,0 			//02A7 	0805

		//;main.c: 157: PAIF = 0;
		BCR 	INTCON,0 		//02A8 	100B

		//;main.c: 158: IOCA2 =0;
		BSR 	STATUS,5 		//02A9 	1A83
		BCR 	16H,2 			//02AA 	1116
		LDR 	71H,0 			//02AB 	0871
		STR 	PCLATH 			//02AC 	018A
		SWAPR 	70H,0 			//02AD 	0770
		STR 	STATUS 			//02AE 	0183
		SWAPR 	7EH,1 			//02AF 	07FE
		SWAPR 	7EH,0 			//02B0 	077E
		RETI		 			//02B1 	0009
		BSR 	STATUS,5 		//02B2 	1A83
		BSR 	5H,0 			//02B3 	1805
		BSR 	5H,1 			//02B4 	1885
		BSR 	5H,2 			//02B5 	1905
		BSR 	5H,3 			//02B6 	1985
		CLRR 	7BH 			//02B7 	017B
		BCR 	STATUS,5 		//02B8 	1283
		CLRR 	58H 			//02B9 	0158
		BSR 	42H,1 			//02BA 	18C2
		CLRR 	79H 			//02BB 	0179
		LCALL 	16H 			//02BC 	3016
		LDWI 	4H 			//02BD 	2A04
		INCR	79H,1 			//02BE 	09F9
		SUBWR 	79H,0 			//02BF 	0C79
		BTSS 	STATUS,0 		//02C0 	1C03
		LJUMP 	2BCH 			//02C1 	3ABC
		BCR 	42H,1 			//02C2 	10C2
		CLRR 	7BH 			//02C3 	017B
		CLRR 	58H 			//02C4 	0158
		RET		 					//02C5 	0004

		//;main.c: 176: unsigned int a;
		//;main.c: 177: for(a=0;a<Time;a++)
		CLRR 	78H 			//02C6 	0178
		CLRR 	79H 			//02C7 	0179
		LDR 	77H,0 			//02C8 	0877
		SUBWR 	79H,0 			//02C9 	0C79
		BTSS 	STATUS,2 		//02CA 	1D03
		LJUMP 	2CEH 			//02CB 	3ACE
		LDR 	76H,0 			//02CC 	0876
		SUBWR 	78H,0 			//02CD 	0C78
		BTSC 	STATUS,0 		//02CE 	1403
		RET		 					//02CF 	0004

		//;main.c: 178: {
		//;main.c: 179: Delay_Us(1000);
		LDWI 	E8H 			//02D0 	2AE8
		STR 	72H 			//02D1 	01F2
		LDWI 	3H 			//02D2 	2A03
		STR 	73H 			//02D3 	01F3
		LCALL 	2D9H 			//02D4 	32D9
		INCR	78H,1 			//02D5 	09F8
		BTSC 	STATUS,2 		//02D6 	1503
		INCR	79H,1 			//02D7 	09F9
		LJUMP 	2C8H 			//02D8 	3AC8

		//;main.c: 166: unsigned int a;
		//;main.c: 167: for(a=0;a<Time;a++)
		CLRR 	74H 			//02D9 	0174
		CLRR 	75H 			//02DA 	0175
		LDR 	73H,0 			//02DB 	0873
		SUBWR 	75H,0 			//02DC 	0C75
		BTSS 	STATUS,2 		//02DD 	1D03
		LJUMP 	2E1H 			//02DE 	3AE1
		LDR 	72H,0 			//02DF 	0872
		SUBWR 	74H,0 			//02E0 	0C74
		BTSC 	STATUS,0 		//02E1 	1403
		RET		 					//02E2 	0004

		//;main.c: 168: {
		//;main.c: 169: __nop();
		NOP		 					//02E3 	0000
		CLRWDT	 			//02E4 	0001
		INCR	74H,1 			//02E5 	09F4
		BTSC 	STATUS,2 		//02E6 	1503
		INCR	75H,1 			//02E7 	09F5
		LJUMP 	2DBH 			//02E8 	3ADB
		LDWI 	2H 			//02E9 	2A02
		STR 	PCLATH 			//02EA 	018A
		LDR 	FSR,0 			//02EB 	0804
		INCR	FSR,1 			//02EC 	0984
		ADDWR 	PCL,1 			//02ED 	0B82
		RETW 	0H 			//02EE 	2100
		RETW 	33H 			//02EF 	2133
		RETW 	AH 			//02F0 	210A
		RETW 	25H 			//02F1 	2125
		RETW 	2AH 			//02F2 	212A
		RETW 	53H 			//02F3 	2153
		RETW 	10H 			//02F4 	2110
		RETW 	3DH 			//02F5 	213D
		RETW 	44H 			//02F6 	2144
		LCALL 	2FEH 			//02F7 	32FE
		BCR 	STATUS,7 		//02F8 	1383
		STR 	INDF 			//02F9 	0180
		INCR	FSR,1 			//02FA 	0984
		LDR 	52H,0 			//02FB 	0852
		STR 	INDF 			//02FC 	0180
		RET		 					//02FD 	0004
		BCR 	STATUS,0 		//02FE 	1003
		RLR 	58H,0 			//02FF 	0558
		ADDWI 	43H 			//0300 	2743
		STR 	FSR 			//0301 	0184
		LDR 	51H,0 			//0302 	0851
		RET		 					//0303 	0004
		CLRWDT	 			//0304 	0001
		CLRR 	INDF 			//0305 	0100
		INCR	FSR,1 			//0306 	0984
		XORWR 	FSR,0 			//0307 	0404
		BTSC 	STATUS,2 		//0308 	1503
		RETW 	0H 			//0309 	2100
		XORWR 	FSR,0 			//030A 	0404
		LJUMP 	305H 			//030B 	3B05
		CLRR 	72H 			//030C 	0172
		NOP		 					//030D 	0000
		LDWI 	19H 			//030E 	2A19
		INCR	72H,1 			//030F 	09F2
		SUBWR 	72H,0 			//0310 	0C72
		BTSC 	STATUS,0 		//0311 	1403
		RET		 					//0312 	0004
		LJUMP 	30DH 			//0313 	3B0D
		BCR 	STATUS,5 		//0314 	1283
		CLRR 	40H 			//0315 	0140
		CLRR 	41H 			//0316 	0141
		BSR 	STATUS,5 		//0317 	1A83
		BSR 	EH,3 			//0318 	198E
		CLRR 	6H 			//0319 	0106
		RET		 					//031A 	0004

		//;main.c: 185: TMR0 = 206;
		LDWI 	CEH 			//031B 	2ACE
		BCR 	STATUS,5 		//031C 	1283
		STR 	1H 			//031D 	0181

		//;main.c: 186: T0IF = 0;
		BCR 	INTCON,2 		//031E 	110B

		//;main.c: 187: T0IE = 1;
		BSR 	INTCON,5 		//031F 	1A8B

		//;main.c: 188: GIE = 1;
		BSR 	INTCON,7 		//0320 	1B8B
		RET		 					//0321 	0004
		BSR 	STATUS,5 		//0322 	1A83
		CLRR 	6H 			//0323 	0106
		BSR 	6H,4 			//0324 	1A06
		BCR 	EH,3 			//0325 	118E
		RET		 					//0326 	0004
			END
