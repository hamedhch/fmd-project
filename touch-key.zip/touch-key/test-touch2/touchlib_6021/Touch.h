#ifndef	_TOUCH_
#define	_TOUCH_

#include "syscfg.h"

#define  uint8_t       unsigned char
#define  uint16_t     unsigned int
#define  uint32_t     unsigned long
#define  BOOL         bit



#define   IO_TOUCH_ATTR	                     0x000F	     //������ʹ�õİ����BBit 0~3��Ӧkey1~key4��0��ʹ�ã�1ʹ��	
#define   TouchCount                                 4               	  //������
#define   LONGKEYPROTECT                       4               	  //(��)��������������, 0 ��ʹ��
#define   SCANNINGTIME					         12                //����ɨ��Ƶ��
#define   WAKEUPFREQUENCY                     32                  //����Ƶ��  ��/��
//KEY ON �ٷֱ�
#define   KEY0_ON					65
#define   KEY1_ON					65
#define   KEY2_ON					65
#define   KEY3_ON					65
//KEY OFF �ٷֱ�
#define   KEY0_OFF					40
#define   KEY1_OFF					40
#define   KEY2_OFF					40
#define   KEY3_OFF					40
//----------------------------------------------------------

//������ֵ	1
#define  KEY0_ACTIVE_SENSOR_DELTA1		116*KEY0_ON/100
#define  KEY1_ACTIVE_SENSOR_DELTA1		103*KEY1_ON/100
#define  KEY2_ACTIVE_SENSOR_DELTA1		92*KEY2_ON/100
#define  KEY3_ACTIVE_SENSOR_DELTA1		102*KEY3_ON/100
//----------------------------------------------------------

//�Ǵ�����ֵ	1
#define  KEY0_INACTIVE_SENSOR_DELTA1		116*KEY0_OFF/100
#define  KEY1_INACTIVE_SENSOR_DELTA1		103*KEY1_OFF/100
#define  KEY2_INACTIVE_SENSOR_DELTA1		92*KEY2_OFF/100
#define  KEY3_INACTIVE_SENSOR_DELTA1		102*KEY3_OFF/100
//----------------------------------------------------------

const uint8_t ACTIVE_SENSOR_DELTA[4]   = 
{
KEY0_ACTIVE_SENSOR_DELTA1,	
KEY1_ACTIVE_SENSOR_DELTA1,	
KEY2_ACTIVE_SENSOR_DELTA1,	
KEY3_ACTIVE_SENSOR_DELTA1,	
};
//----------------------------------------------------------

const uint8_t INACTIVE_SENSOR_DELTA[4]  =
{
KEY0_INACTIVE_SENSOR_DELTA1,	
KEY1_INACTIVE_SENSOR_DELTA1,	
KEY2_INACTIVE_SENSOR_DELTA1,	
KEY3_INACTIVE_SENSOR_DELTA1,	
};
//----------------------------------------------------------

const uint8_t     IO_TOUCH_ATTR1   = IO_TOUCH_ATTR;
const uint8_t     LONGKEYPROTECT1 = LONGKEYPROTECT;
const uint8_t     TouchCount1           = TouchCount;
const uint8_t     SCANNINGTIME1    			  		=SCANNINGTIME;

unsigned char TouchKeyScan();
void Touch_init();
#endif	
